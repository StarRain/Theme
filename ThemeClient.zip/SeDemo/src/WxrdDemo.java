import java.io.File;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.stream.Collectors;

public class WxrdDemo {

    public static void main(String[] args) {
        // 更改打包文件到指定格式
//        renameApk("/Users/cz/Desktop/3jy_document/微信聚合/产品测试/正式包1.60/", "wkd", "1.6.0", ".apk");
//        renameApk("/Users/cz/Desktop/1.8正式包/", "wkd", "1.8.0", ".apk");
//        createChannel(4, 201, 250);//批量输出渠道
//        creatParcelable(FollowInfo.class);//输出实现Parcelable接口的类
//        createDbInterface(FollowInfo.class);//输出与DbInterface结果的class模板
//        outProguardDirectory(new File("/Users/cz/IdeaProjects/SeDemo/src/"));//输出混淆打包
        ArrayList<String> list = new ArrayList<>();
        list.add("a1");
        list.add("a2");
        list.add("a3");
        list.stream().filter(value -> "a1".equals(value)).collect(Collectors.toList());

    }

    /**
     * 生成网络接口操作方法
     *
     * @param clazz
     */
    private static void createDbInterface(Class<?> clazz) {
        createContentValues(clazz);
        createGetDatas(clazz);
    }

    /**
     * 创建contentvalue对象
     *
     * @param clazz
     */
    private static void createContentValues(Class<?> clazz) {
        String overRide = "@Override";
        // 生writeTorcel方法
        String getContentValuesMethod = "getContentValues";
        StringBuilder builder = new StringBuilder();
        builder.delete(0, builder.length());
        builder.append(overRide + "\n");
        builder.append("public ContentValues " + getContentValuesMethod
                + "() {");
        builder.append("\t\n");
        builder.append("\tContentValues values = new ContentValues();\n");
        Field[] fields = clazz.getDeclaredFields();
        int length = fields.length;
        for (int i = 0; i < length; i++) {
            fields[i].setAccessible(true);
            builder.append("\tvalues.put(\"" + fields[i].getName() + "\","
                    + fields[i].getName() + ");\n");
        }
        builder.append("\treturn values;\n");
        builder.append("}");
        System.out.println(builder.toString());
    }

    private static void createGetDatas(Class<?> clazz) {
        String overRide = "@Override";
        // 生writeTorcel方法
        String name = clazz.getSimpleName();
        String getContentValuesMethod = "getDatas";
        StringBuilder builder = new StringBuilder();
        builder.delete(0, builder.length());
        builder.append(overRide + "\n");
        builder.append("public ArrayList<" + name + "> "
                + getContentValuesMethod + "(Cursor cursor) {");
        builder.append("\t\n");
        builder.append("\tArrayList<" + name + "> lists = null;\n");
        builder.append("\tif(null!=cursor){\n");
        builder.append("\t\tlists = new ArrayList<" + name + ">();\n");
        builder.append("\t\twhile(cursor.moveToNext()){\n");
        builder.append("\t\t\tlists.add(new " + name + "(");
        Field[] fields = clazz.getDeclaredFields();
        int length = fields.length;
        for (int i = 0; i < length; i++) {
            fields[i].setAccessible(true);
            Class<?> type = fields[i].getType();
            if (0 == i) {
                builder.append("cursor.get" + getTypeName(type.getSimpleName())
                        + "(" + i + "),\n");
            } else if (i != length - 1) {
                builder.append("\t\t\t\tcursor.get"
                        + getTypeName(type.getSimpleName()) + "(" + i + "),\n");
            } else {
                builder.append("\t\t\t\tcursor.get"
                        + getTypeName(type.getSimpleName()) + "(" + i
                        + ")));\n");
            }
        }
        builder.append("\t\t\t}\n");
        builder.append("\t\t}\n");
        builder.append("\treturn lists;\n");
        builder.append("}\n");
        System.out.println(builder.toString());
    }

    /**
     * 创建java 1:Parcelable 序列化类 2:生成equals 方法, 3:生成dbInterface方法
     *
     * @param clazz
     */
    public static void creatParcelable(Class<?> clazz) {
        createDescrieMethod();
        createWriteParcel(clazz);
        createCreator(clazz);
    }

    private static void createWriteParcel(Class<?> clazz) {
        String overRide = "@Override";
        // 生writeTorcel方法
        String write2ParcelMethod = "writeToParcel";
        StringBuilder builder = new StringBuilder();
        builder.delete(0, builder.length());
        builder.append(overRide);
        builder.append("\n");
        builder.append("public void " + write2ParcelMethod
                + "(Parcel dest,int flags) {");
        builder.append("\t\n");
        Field[] fields = clazz.getDeclaredFields();
        int length = fields.length;
        for (int i = 0; i < length; i++) {
            fields[i].setAccessible(true);
            Class<?> type = fields[i].getType();
            builder.append("\tdest.write" + getTypeName(type.getSimpleName())
                    + "(" + fields[i].getName() + ");\n");
        }
        builder.append("}");
        System.out.println(builder.toString());
    }

    /**
     * 首字母大写
     *
     * @param typeName
     * @return
     */
    private static String getTypeName(String typeName) {
        return typeName.substring(0, 1).toUpperCase() + typeName.substring(1);
    }

    private static void createCreator(Class<?> clazz) {
        // public static final Parcelable.Creator<Music> CREATOR = new
        // Creator<Music>() {
        //
        // @Override
        // public Music[] newArray(int size) {
        // return new Music[size];
        // }
        //
        // @Override
        // public Music createFromParcel(Parcel s) {
        // Music m = new Music();
        // m.directory = s.readString();
        // m.word = s.readString();
        // return m;
        // }
        // };
        String name = clazz.getSimpleName();
        String overRide = "@Override";
        StringBuilder builder = new StringBuilder();
        builder.append("public static final Parcelable.Creator<" + name
                + "> CREATOR = new Parcelable.Creator<" + name + ">() {\n");
        builder.append("\n");
        builder.append("\t" + overRide + "\n");
        builder.append("\tpublic " + name + "[] newArray(int size) {\n");
        builder.append("\t\t return new " + name + "[size];\n");
        builder.append("\t}\n");
        builder.append("\n");
        builder.append("\t" + overRide + "\n");
        builder.append("\tpublic " + name + " createFromParcel(Parcel s) {\n");
        String fieldName = getFieldName(name);
        builder.append("\t\t" + name + " " + fieldName + " = new " + name
                + "();\n");
        Field[] fields = clazz.getDeclaredFields();
        int length = fields.length;
        for (int i = 0; i < length; i++) {
            fields[i].setAccessible(true);
            Class<?> type = fields[i].getType();
            builder.append("\t\t" + fieldName + "." + fields[i].getName()
                    + " = " + "s.read" + getTypeName(type.getSimpleName())
                    + "();\n");
        }
        builder.append("\t\treturn " + fieldName + ";\n");
        builder.append("\t}\n");
        builder.append("\n};");
        System.out.println(builder.toString());
    }

    private static String getFieldName(String name) {
        return name.substring(0, 1).toLowerCase() + name.substring(1);
    }

    /**
     * 生成describe方法
     */
    private static void createDescrieMethod() {
        // 生成三个方法
        // @Override
        // public int describeContents() {
        // return 0;
        // }
        String overRide = "@Override";

        // 生成describeContaents()方法
        String describeMethod = "describeContents";
        StringBuilder builder = new StringBuilder();
        builder.append(overRide);
        builder.append("\n");
        builder.append("public int " + describeMethod + "(){");
        builder.append("\n");
        builder.append("\t" + "return 0;" + "\n}");
        System.out.println(builder.toString());
    }

    /**
     * 生成渠道号
     */
    public static void createChannel(int c, int start, int count) {
        DecimalFormat formater = new DecimalFormat("000");
        for (int i = start; i <= count; i++) {
            System.out.println("c" + c + formater.format(i) + "{}");
        }
    }

    /**
     * 批量修改文件名称
     *
     * @param version
     */
    public static void renameApk(String path, String appName, String version,
                                 String suffix) {
        File file = new File(path);
        File[] files = file.listFiles();
        if (null != files) {
            int length = files.length;
            for (int i = 0; i < length; i++) {
                String name = files[i].getName();
                if (null != name && !name.startsWith(appName)
                        && name.endsWith(".apk")) {
                    String[] channels = name.split("-");
                    files[i].renameTo(new File(file, appName + "_" + version
                            + "_" + channels[1] + suffix));
                }
            }
            System.out.println("更改成功!");
        }
    }

    /**
     * 生成混淆打包目录
     *
     * @param file
     */
    public static void outProguardDirectory(File file) {
        if (file.isDirectory()) {
            // -keep class
            LinkedList<File> files = new LinkedList<>();
            files.add(file);
            while (!files.isEmpty()) {
                File temp = files.removeFirst();
                if (temp.isDirectory()) {
                    File[] listFiles = temp.listFiles();
                    if (null != listFiles) {
                        for (int i = 0; i < listFiles.length; i++) {
                            if (listFiles[i].isDirectory()
                                    && !listFiles[i].getName().endsWith("svn")) {
                                files.add(listFiles[i]);
                            }
                        }
                    }
                    System.out.println("-keep class " + getPackagePath(temp)
                            + ".** { *; }");
                }
            }
        }
    }

    private static String getPackagePath(File temp) {
        String path = temp.getAbsolutePath();
        path = path.replace("\\", ".");// 去掉反斜
        int index = path.indexOf("com");
        return path.substring(index);
    }


}
