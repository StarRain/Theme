package theme;

/**
 * Created by cz on 15/9/8.
 */
public class ThemeAttr {
    String key = "";
}
