package theme.bean;

import java.util.ArrayList;

/**
 * Created by cz on 15/8/8.
 * 主题元素
 */
public class StyleElement {

    public String id;
    public String view;
    public ArrayList<Element> items;

    public StyleElement() {
        items = new ArrayList<>();
    }

    public StyleElement(String id) {
        this.id = id;
        items = new ArrayList<>();
    }

    @Override
    public String toString() {
        return id + " " + items + "\n";
    }

    public static class Element {
        public String type;
        public String resType;
        public String attrValue;
        public String value;

        public Element(String type, String resType, String attrValue, String value) {
            this.type = type;
            this.resType = resType;
            this.attrValue = attrValue;
            this.value = value;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            Element r = (Element) o;
            return resType.equals(r.resType) && value.equals(r.value);
        }

        @Override
        public String toString() {
            return "type:" + type + " resType:" + resType + " attrValeu:" + attrValue + " value:" + value;
        }
    }

}
