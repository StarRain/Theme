package theme.bean;

/**
 * Created by cz on 15/10/14.
 * 列表条目
 */
public class ListItem {
    public String name;
    public String id;

    public ListItem(String name, String id) {
        this.name = name;
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ListItem r = (ListItem) o;
        return id.equals(r.id);
    }
}
