package theme.bean;

/**
 * Created by cz on 15/10/15.
 */
public class ViewLayout {
    public String layout;
    public String id;

    public ViewLayout(String layout, String id) {
        this.layout = layout;
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ViewLayout r = (ViewLayout) o;
        return id.equals(r.id)&&layout.equals(r.layout);
    }
}
