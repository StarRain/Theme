package theme.bean;

import java.util.ArrayList;

/**
 * Created by cz on 15/9/10.
 * 项目配置
 */
public class ModuleConfig {
    public String author;
    public String modulePath;
    public String constantStringDef;
    public String resLayout;
    public String srcJava;
    public String themeConfigDir;
    public String themeLayout;
    public String themeStyle;
    public String themeMapped;
    public String themeFilterMapped;
    public String themeAttr;
    public String themeConstants;
    public String themePackage;
    public String themeList;
    public String themeListLayout;
    public String themeViewLayout;
    public ArrayList<String> themeLists;
    public ArrayList<String> styleNames;

    public ModuleConfig() {
        styleNames = new ArrayList<>();
        themeLists = new ArrayList<>();
    }

    @Override
    public String toString() {
        return "\nauthor:" + author + "\n" +
                "modulePath:" + modulePath + "\n" +
                "constantStringDef:" + constantStringDef + "\n" +
                "resLayout:" + resLayout + "\n" +
                "srcJava:" + srcJava + "\n" +
                "themeConfigDir:" + themeConfigDir + "\n" +
                "themeLayout:" + themeLayout + "\n" +
                "themeStyle:" + themeStyle + "\n" +
                "themeMapped:" + themeMapped + "\n" +
                "themeFilterMapped:" + themeFilterMapped + "\n" +
                "themeAttr:" + themeAttr + "\n" +
                "themeConstants:" + themeConstants + "\n" +
                "themePackage:" + themePackage + "\n" +
                "themeList:" + themeList + "\n" +
                "themeListLayout:" + themeListLayout + "\n" +
                "themeViewLayout:" + themeViewLayout + "\n" +
                "styleNames:" + styleNames + "\n";
    }
}
