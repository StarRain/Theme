package theme.bean;

/**
 * Created by cz on 15/10/15.
 * 控件信息
 */
public class ViewInfo {
    public String info;
    public String id;

    public ViewInfo(String info, String id) {
        this.info = info;
        this.id = id;
    }

}
