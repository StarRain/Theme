package theme.bean;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Created by cz on 15/8/8.
 * 引用类型
 */
public enum ResType {
    setImageResource(),
    setImageResourceFilter(),
    setBackgroundResource(),
    setBackgroundResourceFilter(),
    setTextColor(),
    setHintTextColor(),
    leftDrawable(),
    leftDrawableFilter(),
    topDrawable(),
    topDrawableFilter(),
    rightDrawable(),
    rightDrawableFilter(),
    bottomDrawable(),
    bottomDrawableFilter(),
    other(),;

    private static final ArrayList<String> ATTR_TYPES;

    static {
        ATTR_TYPES = new ArrayList<>();
        ATTR_TYPES.add("src");
        ATTR_TYPES.add("srcFilter");
        ATTR_TYPES.add("background");
        ATTR_TYPES.add("backgroundFilter");
        ATTR_TYPES.add("textColor");
        ATTR_TYPES.add("textColorHint");
        ATTR_TYPES.add("drawableLeft");
        ATTR_TYPES.add("drawableLeftFilter");
        ATTR_TYPES.add("drawableTop");
        ATTR_TYPES.add("drawableTopFilter");
        ATTR_TYPES.add("drawableRight");
        ATTR_TYPES.add("drawableRightFilter");
        ATTR_TYPES.add("drawableBottom");
        ATTR_TYPES.add("drawableBottomFilter");
    }

    public String value;

    ResType() {
    }

    public static ResType getType(String name) {
        ResType resType;
        int i = ATTR_TYPES.indexOf(name);
        if (-1 != i) {
            //北影可以设置颜色,也可以设置drawable对象
            resType = ResType.values()[i];
            resType.value = resType.toString();
        } else {
            resType = ResType.valueOf("other");
            int index = name.indexOf("_");
            if (-1 != index) {
                //自定义属性
                String attrName = name.substring(index + 1);
                name = "set" + attrName.substring(0, 1).toUpperCase(Locale.CHINA) + attrName.substring(1);
            }
            other.value = name;
        }
        return resType;
    }

}
