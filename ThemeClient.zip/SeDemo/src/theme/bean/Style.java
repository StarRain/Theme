package theme.bean;

import java.util.ArrayList;

/**
 * Created by cz on 15/8/9.
 * 样式集
 */
public class Style {
    public String name;
    public int value;
    public ArrayList<AttrItem> items;

    public Style(String name, int value) {
        this.name = name;
        this.value = value;
        this.items = new ArrayList<>();
    }

    public static class AttrItem {
        public String name;
        public AttrType type;
        public String value;

        public AttrItem() {
        }

        public AttrItem(String name, String value) {
            this.name = name;
            this.value = value;
        }

        @Override
        public int hashCode() {
            return name.hashCode();
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            AttrItem r = (AttrItem) o;
            return name.equals(r.name);
        }


    }
}
