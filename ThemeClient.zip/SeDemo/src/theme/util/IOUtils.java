package theme.util;

import java.io.*;

public class IOUtils {

    public static String stream2String(final InputStream instream) throws IOException {
        final StringBuilder sb = new StringBuilder();
        try {
            final BufferedReader reader = new BufferedReader(new InputStreamReader(instream, "UTF-8"));
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } finally {
            closeStream(instream);
        }
        return sb.toString();
    }

    /**
     * 关闭IO流对象
     *
     * @param streams
     */
    public static void closeStream(Closeable... streams) {
        if (null != streams) {
            try {
                for (int i = 0; i < streams.length; i++) {
                    if (null != streams[i]) {
                        streams[i].close();
                    }
                }
            } catch (IOException e) {
            }
        }
    }

    /**
     * 获取文件的内容，以字符串的形式返回， 注：暂没有考虑编码问题
     *
     * @return 文件内容，如果没有文件，返回空
     */
    public static String getFileContent(File file) {
        if (file.exists()) {
            StringBuilder builder = new StringBuilder();
            BufferedReader bufferedReader = null;
            try {
                FileReader reader = new FileReader(file);
                bufferedReader = new BufferedReader(reader);
                String lineTxt = null;
                while ((lineTxt = bufferedReader.readLine()) != null) {
                    builder.append(lineTxt);
                }
                bufferedReader.close();
            } catch (Exception e) {
            } finally {
                if (bufferedReader != null) {
                    bufferedReader = null;
                }
            }
            return builder.toString();
        }
        return null;
    }
}
