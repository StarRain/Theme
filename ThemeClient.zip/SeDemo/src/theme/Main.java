package theme;


import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import theme.bean.*;
import theme.read.LayoutReader;
import util.DateUtils;
import util.FileUtils;
import xml.XmlUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Field;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by cz on 15/8/8.
 *
 * @update 15/8/8 更新
 */
public class Main {
    private static final ModuleConfig mConfig;

    static {
        mConfig = new ModuleConfig();
        File configFile = new File(System.getProperty("user.dir") + "/conf/theme_config");
//        System.out.println(configFile.getAbsolutePath());
        if (!configFile.exists()) throw new IllegalArgumentException("configFile 不能执行");
        SAXReader reader = new SAXReader();
        Document document;
        try {
            document = reader.read(configFile);
            if (null != document) {
                Element rootElement = document.getRootElement();
                int count = rootElement.attributeCount();
                for (int i = 0; i < count; i++) {
                    Attribute attribute = rootElement.attribute(i);
                    try {
                        String name = attribute.getName();
                        String value = attribute.getValue();
                        Field field = mConfig.getClass().getField(name);
                        field.set(mConfig, value);
                    } catch (NoSuchFieldException e) {
                        e.printStackTrace();
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }
                }
                List<Element> elements = rootElement.elements();
                elements.forEach(element -> {
                    String name = element.getName();
                    if ("path".equals(name)) {
                        List<Element> pathElements = element.elements();
                        pathElements.forEach(pathElement -> {
                            try {
                                String attrName = pathElement.attributeValue("name");
                                String attrValue = pathElement.attributeValue("value");
                                Field field = mConfig.getClass().getField(attrName);
                                field.set(mConfig, attrValue);
                            } catch (NoSuchFieldException e) {
                                e.printStackTrace();
                            } catch (IllegalAccessException e) {
                                e.printStackTrace();
                            }
                        });
                    } else if ("style".equals(name)) {
                        List<Element> styleElement = element.elements();
                        styleElement.forEach(item -> mConfig.styleNames.add(item.attributeValue("value")));
                    }

                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        //初始化列表控件
        String[] listValues = mConfig.themeList.split("\\|");
        if (0 != listValues.length) {
            mConfig.themeLists.addAll(Arrays.asList(listValues));
        }

        System.out.println("==========================初始化配置完成==========================");
        System.out.println(mConfig);
        System.out.println("================================================================");
    }

    public static void main(String[] args) {
        createThemeResource(new File(mConfig.modulePath));
        //测试获取代码引用资源
//        读取style.xml
//        HashMap<Integer, Style> styles = StyleReader.readStyles(new File("/Users/cz/Desktop/style.xml"));
//        System.out.println(styles.size());


        //1:测索出所有自定义使用的layout
        //2:与使用对象建立关系
//        View headerView = View.inflate(getActivity(), R.layout.find_header_layout, null);
//        LayoutInflater.from(getActivity()).inflate(R.layout.account_subscribe_list_item, headerView, false);
//        File moduleFile = new File(mConfig.modulePath);
////        File srcFile = new File(moduleFile, mConfig.srcJava);
//        File srcFile = new File("/Users/cz/Desktop/master/wxrd_v1.10/weixinredian/src/main/java/com/weishang/wxrd/ui/FindFragment.java");
//        final Pattern pattern = Pattern.compile("([\\w\\s])");
//        FileUtils.scanFile(srcFile, new FileUtils.ScanListener<File>() {
//            @Override
//            public void scan(File file) {
//                if (!file.isDirectory() && file.getName().endsWith(".java")) {
//                    BufferedReader reader = null;
//                    try {
//                        //扫描文件内容
//                        reader = new BufferedReader(new FileReader(file));
//                        String line;
//                        while (null != (line = reader.readLine())) {
//                            System.out.println(line);
////                            Matcher matcher = pattern.matcher(line);
////                            if (matcher.find()) {
////                                String resType = matcher.group(1);
////                                String value = matcher.group(2);
////                            }
//                        }
//                    } catch (Exception e) {
//                    } finally {
//                        IOUtils.closeStream(reader);
//                    }
//                }
//            }
//
//            @Override
//            public Void result() {
//                return null;
//            }
//        });

    }

    public static void createThemeResource(File moduleFile) {
        File configFile = new File(moduleFile, mConfig.themeConfigDir);
        if (!configFile.exists()) {
            configFile.mkdirs();
        }
        long st = System.currentTimeMillis();
        ArrayList<LayoutMapped> layoutMappeds = new ArrayList<>();
        //记录布局内,第一层容器id
        HashMap<String, String> layoutIds = new HashMap<>();
        //记录所有的列表对象
        HashMap<String, ArrayList<ListItem>> listItems = new HashMap<>();
        //记录所有过滤列表
        TreeSet<DrawableFilterAttrItem.FilterAttrItem> drawableFilterAttrItems = new TreeSet<>((o1, o2) -> o1.attr.compareTo(o2.attr));
        //记录所有自定义控件
        HashMap<String, ArrayList<ViewInfo>> viewInfos = new HashMap<>();
        //记录drawableFilter过滤映射
        //扫描xml内容
        ArrayList<Style.AttrItem> attrs = createLayoutXml(moduleFile, mConfig.themeLists, listItems, layoutIds, drawableFilterAttrItems, viewInfos);
        //扫描java使用引用
        ArrayList<Style.AttrItem> srcAttrs = scanSrcAttrs(moduleFile, layoutMappeds, layoutIds, drawableFilterAttrItems);
        //记录布局与类之间的引用关系
        initMappedLayout(moduleFile, layoutMappeds, layoutIds);
        //记录布局内的列表元素
        createLayoutListXml(moduleFile, listItems);
        //记录布局内的自定义组合控件
        createViewLayout(moduleFile, layoutMappeds, viewInfos);

        //文件记录时间
        String time = DateUtils.getFromat("yyyy/MM/dd hh时mm分", System.currentTimeMillis());
        if (!attrs.isEmpty()) {
            System.out.println("========================开始检测所有引用========================");
            srcAttrs.removeAll(attrs);
            System.out.println("布局内引用:" + attrs.size() + " 代码内引用:" + srcAttrs.size());
            attrs.addAll(srcAttrs);
            System.out.println("总的引用:" + attrs.size());
            //生成两套主题引用列表
            createOrUpdateThemeStyle(moduleFile, new ArrayList<>(attrs));
            createOrUpdateAttrClass(new File(moduleFile, mConfig.themeAttr), mConfig.themePackage, attrs, time);
        }
        //初始化drawable颜色过滤引用映射集
        createOrUpdateDrawableFilterColorMapped(moduleFile, new ArrayList<>(drawableFilterAttrItems));
        //添加主题信息常量
        createOrUpdateThemeConstantClass(moduleFile, time);

        System.out.println("初始化主题信息完成,耗时:" + (System.currentTimeMillis() - st));
    }

    /**
     * 创建列表布局的xml
     *
     * @param moduleFile
     * @param listItems
     */
    private static void createLayoutListXml(File moduleFile,
                                            HashMap<String, ArrayList<ListItem>> listItems) {
        File listLayout = new File(moduleFile, mConfig.themeListLayout);
        System.out.println("========================列表初始化对象:" + listItems.size() + "========================");
        if (!listItems.isEmpty()) {
            Document document = DocumentHelper.createDocument();
            Element rootElement = document.addElement("list");
            listItems.forEach((fileName, items) -> {
                Element layout = rootElement.addElement("layout");
                layout.addAttribute("name", fileName);
                if (!items.isEmpty()) {
                    items.forEach(item -> layout.addElement("item").addAttribute("id", item.id).addAttribute("view", item.name));
                }
            });
            XmlUtils.writeXml(listLayout, document);
        }

    }

    private static void createViewLayout(File moduleFile, ArrayList<LayoutMapped> layoutMappeds,
                                         HashMap<String, ArrayList<ViewInfo>> viewInfos) {
        System.out.println("========================列表自定义模板控件========================");
        File listLayout = new File(moduleFile, mConfig.themeViewLayout);
        //记录所有的自定义控件集
        HashMap<String, ViewInfo> customViewInfos = new HashMap<>();
        viewInfos.forEach((layoutName, infos) -> infos.forEach(info -> customViewInfos.put(info.info, info)));
        //记录所有的Class=LayoutMapped集合
        HashMap<String, LayoutMapped> layoutMappedMap = new HashMap<>();
        layoutMappeds.forEach(layoutMapped -> layoutMappedMap.put(layoutMapped.name, layoutMapped));


        HashMap<String, LayoutMapped> filterLayoutMappeds = new HashMap<>();
        //遍历自定义控件,获取所有使用了layout的控件
        customViewInfos.forEach((viewName, info) -> {
            //记录该view   FrameLayout==frame_layout
            if (layoutMappedMap.containsKey(viewName)) {
                filterLayoutMappeds.put(viewName, layoutMappedMap.get(viewName));
            }
        });

        HashMap<String, ArrayList<ViewLayout>> viewLayouts = new HashMap<>();
        //遍历布局->自定义控件集
        viewInfos.forEach((layoutName, infos) -> {
            infos.forEach(info -> {
                String viewName = info.info;
                LayoutMapped layoutMapped = layoutMappedMap.get(viewName);
                if (null != layoutMapped) {
                    //代表记录存在
                    ArrayList<String> layouts = layoutMapped.layout;
                    layouts.forEach(name -> {
                        ArrayList<ViewLayout> items = viewLayouts.get(layoutName);
                        if (null == items) {
                            items = new ArrayList<>();
                            viewLayouts.put(layoutName, items);
                        }
                        items.add(new ViewLayout(name, info.id));
                    });
                }
            });
        });


        if (!viewLayouts.isEmpty()) {
            Document document = DocumentHelper.createDocument();
            Element rootElement = document.addElement("list");
            viewLayouts.forEach((fileName, items) -> {
                Element layout = rootElement.addElement("layout");
                layout.addAttribute("name", fileName);
                if (!items.isEmpty()) {
                    items.forEach(item -> layout.addElement("item").addAttribute("id", item.id).addAttribute("layout", item.layout));
                }
            });
            XmlUtils.writeXml(listLayout, document);
        }
    }

    /**
     * 创建更新主题常量信息类
     *
     * @param moduleFile
     */
    private static void createOrUpdateThemeConstantClass(File moduleFile, String time) {
        String themeConstants = mConfig.themeConstants;
        File constantFile = new File(moduleFile, themeConstants);
        String constantName = constantFile.getName();
        String className = constantName.substring(0, constantName.lastIndexOf("."));
        ArrayList<String> styleNames = mConfig.styleNames;
        StringBuilder builder = new StringBuilder();
        //生成类信息
        builder.append("package " + mConfig.themePackage + ";\n");
        builder.append("\n");
        builder.append("import android.support.annotation.StringDef;\n");
        builder.append("import java.util.ArrayList;\n");
        builder.append("\n");
        builder.append("/**\n");
        builder.append(" * Created by " + mConfig.author + " on " + time + ".\n");
        builder.append(" */\n");
        builder.append("public class " + className + "{\n");
        int size = styleNames.size();
        //填写主题
        for (int i = 0; i < size; i++) {
            String name = styleNames.get(i);
            //主题取值
            builder.append("\tpublic static final String " + name.toUpperCase() + " = \"" + name + "\";\n");
        }
        builder.append("\tpublic static final ArrayList<String> THEMES;\n");

        builder.append("\n\tstatic {\n");
        builder.append("\t\tTHEMES = new ArrayList<>();\n");
        //填写主题
        for (int i = 0; i < size; i++) {
            String name = styleNames.get(i);
            //主题取值
            builder.append("\t\tTHEMES.add(" + name.toUpperCase() + ");\n");
        }
        builder.append("\t}\n");

        //增加主题intDef文件
        if (Boolean.valueOf(mConfig.constantStringDef)) {
            builder.append("\n\n\t@StringDef({");
            for (int i = 0; i < size; i++) {
                //主题取值
                String name = styleNames.get(i);
                builder.append(name.toUpperCase() + ((i != size - 1) ? "," : "})\n"));
            }
            builder.append("\t@interface Constant{\n\t}\n");
        }
        builder.append("}\n");

        //写入字符
        try {
            FileWriter writer = new FileWriter(constantFile);
            writer.write(builder.toString());
            writer.close();
            System.out.println("更新主题常量类成功!");
        } catch (Exception e) {
        }
    }

    /**
     * 生成drawable颜色过滤的映射
     *
     * @param moduleFile
     * @param fitlerMappeds
     */
    private static void createOrUpdateDrawableFilterColorMapped(File moduleFile, ArrayList<DrawableFilterAttrItem.FilterAttrItem> fitlerMappeds) {
        if (fitlerMappeds.isEmpty()) return;
        System.out.println("========================开始检测所有filter引用========================");
        File drawableFilterFile = new File(moduleFile, mConfig.themeFilterMapped);
        ArrayList<String> styleNames = mConfig.styleNames;
        int size = styleNames.size();
        //初始化插入操作
        Document document = DocumentHelper.createDocument();
        Element rootElement = document.addElement("mapped");
        if (drawableFilterFile.exists()) {
            //更新操作
            ArrayList<DrawableFilterAttrItem> mappedItems = getDrawableFilterMappedItems(drawableFilterFile);
            HashMap<String, DrawableFilterAttrItem> styleMappedItems = new HashMap<>();
            mappedItems.forEach(item -> styleMappedItems.put(item.name, item));
            for (int i = 0; i < size; i++) {
                String name = styleNames.get(i);
                if (styleMappedItems.containsKey(name)) {
                    ArrayList<DrawableFilterAttrItem.FilterAttrItem> newItems = new ArrayList<>(fitlerMappeds);
                    DrawableFilterAttrItem locaItems = styleMappedItems.get(name);
                    newItems.removeAll(locaItems.items);
                    newItems.addAll(locaItems.items);
                    addDrawableFilterMappedItems(newItems, name, i, rootElement);
                } else {
                    addDrawableFilterMappedItems(fitlerMappeds, name, i, rootElement);
                }
            }
        } else {
            for (int i = 0; i < size; i++) {
                String name = styleNames.get(i);
                addDrawableFilterMappedItems(fitlerMappeds, name, i, rootElement);
            }
        }
        XmlUtils.writeXml(drawableFilterFile, document);
        System.out.println("检索Filter引用完毕");
    }

    private static void addDrawableFilterMappedItems(ArrayList<DrawableFilterAttrItem.FilterAttrItem> fitlerMappeds, String name, int i, Element rootElement) {
        Element style = rootElement.addElement("style");
        style.addAttribute("name", name);
        style.addAttribute("value", String.valueOf(i));
        fitlerMappeds.forEach(drawableFilterAttr -> {
            Element item = style.addElement("item");
            item.addAttribute("attr", drawableFilterAttr.attr);
            String color = "@color/";
            if (0 == i) {
                color = "@color/white";
            } else if (null != drawableFilterAttr.color) {
                color = drawableFilterAttr.color;
            }
            item.addAttribute("color", color);
        });
    }

    /**
     * 获得映射布局对象体
     *
     * @param mappedFile
     */
    private static ArrayList<DrawableFilterAttrItem> getDrawableFilterMappedItems(File mappedFile) {
        ArrayList<DrawableFilterAttrItem> filterAttrItems = new ArrayList<>();
        SAXReader reader = new SAXReader();
        Document document;
        try {
            document = reader.read(mappedFile);
            if (null != document) {
                Element rootElement = document.getRootElement();
                List<Element> elements = rootElement.elements();
                elements.forEach(styleElement -> {
                    DrawableFilterAttrItem item = new DrawableFilterAttrItem(styleElement.attributeValue("name"), styleElement.attributeValue("value"));
                    filterAttrItems.add(item);
                    List<Element> itemElements = styleElement.elements();
                    itemElements.forEach(itemElement -> item.items.add(new DrawableFilterAttrItem.FilterAttrItem(itemElement.attributeValue("attr"), itemElement.attributeValue("color"))));
                });
            }
        } catch (Exception e) {
        }
        return filterAttrItems;
    }

    /**
     * 初始化
     *
     * @param moduleFile
     * @param mappedLayouts
     */
    private static void initMappedLayout(File moduleFile, ArrayList<LayoutMapped> mappedLayouts, HashMap<String, String> layoutIds) {
        File mappedFile = new File(moduleFile, mConfig.themeMapped);
        if (mappedFile.exists()) {
            ArrayList<LayoutMapped> localMappedLayouts = getMappedLayouts(mappedFile);
            if (!localMappedLayouts.isEmpty()) {
                mappedLayouts.forEach(mapped -> {
                    int index = -1;
                    if (-1 != (index = localMappedLayouts.indexOf(mapped))) {
                        mapped.enable = localMappedLayouts.get(index).enable;//记录启用状态
                    }
                });
            }
        }
        createMappedLayout(mappedFile, mappedLayouts, layoutIds);
    }

    /**
     * 获得映射布局对象体
     *
     * @param mappedFile
     */
    private static ArrayList<LayoutMapped> getMappedLayouts(File mappedFile) {
        ArrayList<LayoutMapped> mappedLayouts = new ArrayList<>();
        SAXReader reader = new SAXReader();
        Document document;
        try {
            document = reader.read(mappedFile);
            if (null != document) {
                Element rootElement = document.getRootElement();
                List<Element> elements = rootElement.elements();
                elements.forEach(element -> {
                    String name = element.attributeValue("name");
                    String id = element.attributeValue("id");
                    Boolean enable = Boolean.valueOf(element.attributeValue("enable"));
                    final LayoutMapped layoutMapped = new LayoutMapped(name, id, enable);
                    mappedLayouts.add(layoutMapped);
                    List<Element> layoutElements = element.elements();
                    layoutElements.forEach(layoutElement -> layoutMapped.layout.add(layoutElement.attributeValue("name")));
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mappedLayouts;
    }

    /**
     * 创建布局体映射关闭列
     *
     * @param mappeds
     */
    private static void createMappedLayout(File mappedFile, ArrayList<LayoutMapped> mappeds, HashMap<String, String> layoutIds) {
        System.out.println("布局映射对象:" + mappeds.size());
        if (!mappeds.isEmpty()) {
            Document document = DocumentHelper.createDocument();
            Element rootElement = document.addElement("mapped");
            mappeds.forEach(mapped -> {
                Element layout = rootElement.addElement("layout");
                layout.addAttribute("name", mapped.name);
                if (!mapped.layout.isEmpty()) {
                    mapped.layout.forEach(name -> {
                        String id = layoutIds.get(name);
                        Element item = layout.addElement("item").addAttribute("name", name);
                        if (null != id) {
                            item.addAttribute("id", id);
                        }
                    });
                }
                if (mapped.enable) {
                    layout.addAttribute("enable", String.valueOf(mapped.enable));
                }
            });
            XmlUtils.writeXml(mappedFile, document);
        }
    }

    /**
     * 扫描代码内使用的资源
     *
     * @param moduleFile
     */
    private static ArrayList<Style.AttrItem> scanSrcAttrs(File moduleFile, ArrayList<LayoutMapped> layoutAttrs, HashMap<String, String> layoutIds, TreeSet<DrawableFilterAttrItem.FilterAttrItem> drawableFilterAttrItems) {
        Pattern pattern = Pattern.compile("R\\.(drawable|color|mipmap|layout)\\.(\\w*)");
        File srcFile = new File(moduleFile, mConfig.srcJava);
        FileUtils.ScanListener<File> listener = null;
        if (srcFile.exists()) {
            FileUtils.scanFile(srcFile, listener = new FileUtils.ScanListener<File>() {
                TreeSet<Style.AttrItem> srcAttrs = new TreeSet<>((o1, o2) -> o1.name.compareTo(o2.name));

                @Override
                public void scan(File file) {
                    if (!file.isDirectory() && file.getName().endsWith(".java")) {
                        try {
                            //扫描文件内容
                            BufferedReader reader = new BufferedReader(new FileReader(file));
                            String name = file.getName();
                            String fileName = name.substring(0, name.lastIndexOf("."));
                            String id = layoutIds.get(fileName);
                            LayoutMapped mapped = new LayoutMapped(fileName, id);
                            String line;
                            while (null != (line = reader.readLine())) {
                                Matcher matcher = pattern.matcher(line);
                                if (matcher.find()) {
                                    String resType = matcher.group(1);
                                    String value = matcher.group(2);

                                    if ("layout".equals(resType)) {
                                        if (!layoutAttrs.contains(mapped)) {
                                            layoutAttrs.add(mapped);
                                        }
                                        //不添加相同扫描记录
                                        if (!mapped.layout.contains(value)) {
                                            mapped.layout.add(value);
                                        }
                                    } else {
                                        if ("drawable".equals(resType) && value.endsWith("_filter")) {
                                            //添加颜色过滤引用
                                            drawableFilterAttrItems.add(new DrawableFilterAttrItem.FilterAttrItem(value));
                                        }
                                        srcAttrs.add(new Style.AttrItem(resType + "_" + value, "@" + resType + "/" + value));
                                    }
                                }
                            }
                            reader.close();
                        } catch (Exception e) {
                        }
                    }
                }

                @Override
                public ArrayList<Style.AttrItem> result() {
                    return new ArrayList<>(srcAttrs);
                }
            });
        }
        ArrayList<Style.AttrItem> attrs = new ArrayList<>();
        if (null != listener) {
            ArrayList<Style.AttrItem> srcAttrs = listener.result();
            if (null != srcAttrs) {
                attrs.addAll(srcAttrs);
            }
        }
        return attrs;
    }

    /**
     * 创建布局内的代表布局操作的layout文件
     *
     * @param moduleFile
     * @param drawableFilterAttrItems
     * @return
     */
    private static ArrayList<Style.AttrItem> createLayoutXml(File moduleFile,
                                                             ArrayList<String> filterListViews,
                                                             HashMap<String, ArrayList<ListItem>> listItems,
                                                             HashMap<String, String> layoutIds,
                                                             TreeSet<DrawableFilterAttrItem.FilterAttrItem> drawableFilterAttrItems,
                                                             HashMap<String, ArrayList<ViewInfo>> viewInfos) {
        long st = System.currentTimeMillis();
        System.out.println("==========================初始化布局操作==========================");
        TreeSet<Style.AttrItem> attrs = new TreeSet<>((o1, o2) -> o1.name.compareTo(o2.name));
        File layoutFile = new File(moduleFile, mConfig.resLayout);
        if (!layoutFile.exists()) return new ArrayList<>();
        //扫描layout布局文件
        File[] files = layoutFile.listFiles();
        if (null != files && 0 != files.length) {
            ArrayList<String> includeLayouts = new ArrayList<>();
            HashMap<String, ArrayList<StyleElement>> layoutItems = new HashMap<>();
            for (int i = 0; i < files.length; i++) {
                File file = files[i];
                String name = file.getName();
                if (!name.endsWith(".xml")) continue;//必须为xml对象
                final String fileName = name.substring(0, name.lastIndexOf("."));
                ArrayList<StyleElement> styleElements = LayoutReader.readLayout(file, includeLayouts, filterListViews, listItems, layoutIds, drawableFilterAttrItems, viewInfos);
                if (null != styleElements && !styleElements.isEmpty()) {
                    //记录文件内容
                    layoutItems.put(fileName, styleElements);
                }
            }
            //获取所有的include标签内容,并处理包含关系
            if (!includeLayouts.isEmpty()) {
                includeLayouts.forEach((value) -> {
                    String[] values = value.split("\\|");
                    if (2 == values.length) {
                        String key = values[0];
                        String include = values[1];
                        ArrayList<StyleElement> styleElements = layoutItems.get(key);
                        ArrayList<StyleElement> includeElements = layoutItems.get(include);
                        if (null != styleElements && null != includeElements) {
                            styleElements.addAll(includeElements);
                        }
                    }
                });
            }

            //生成对应操作的layout.xml配置
            Document document = DocumentHelper.createDocument();
            final Element root = document.addElement("resources");

            layoutItems.forEach((fileName, styleElements) -> {
                final Element layout = root.addElement("layout");//写入style_layout文件
                layout.addAttribute("name", fileName);
                styleElements.forEach((styleElement) -> {
                    if (null != styleElement.items) {
                        final Element view = layout.addElement("view");
                        view.addAttribute("id", styleElement.id);//添加view id
                        StringBuilder attrName = new StringBuilder();
                        StringBuilder attrValue = new StringBuilder();
                        styleElement.items.forEach((element) -> {
                            attrName.append(element.type + "|");
                            attrValue.append(element.resType + "_" + element.attrValue + "|");
                            attrs.add(new Style.AttrItem(element.resType + "_" + element.attrValue, element.value));
                        });
                        if (!styleElement.items.isEmpty()) {
                            attrName.deleteCharAt(attrName.length() - 1);
                            attrValue.deleteCharAt(attrValue.length() - 1);
                            view.addAttribute("type", attrName.toString());
                            view.addAttribute("attr", attrValue.toString());
                        }
                    }
                });
            });
            XmlUtils.writeXml(new File(moduleFile, mConfig.themeLayout), document);
        }
        System.out.println("初始化布局操作完成,耗时:" + (System.currentTimeMillis() - st));
        return new ArrayList<>(attrs);
    }

    /**
     * 生成主题样式引用集
     *
     * @param moduleFile
     * @param attrs
     */
    private static void createOrUpdateThemeStyle(File moduleFile, ArrayList<Style.AttrItem> attrs) {
        System.out.println("========================开始更新style引用集Xml文件========================");
        long st = System.currentTimeMillis();
        //解析获得之前全部引用
        File styleFile = new File(moduleFile, mConfig.themeStyle);
        //上一个版本引用
        ArrayList<Style> localStyle = getThemeStyle(styleFile);

        HashMap<String, Style> localStyleMap = new HashMap<>(localStyle.size());
        localStyle.forEach(style -> localStyleMap.put(style.name, style));

        Document document = DocumentHelper.createDocument();
        Element resources = document.addElement("resources");

        ArrayList<String> styleNames = mConfig.styleNames;
        int size = styleNames.size();
        if (!localStyle.isEmpty()) {
            //主题更变
            System.out.println("使用的主题名称:" + styleNames);
            for (int i = 0; i < size; i++) {
                String name = styleNames.get(i);
                if (localStyleMap.containsKey(name)) {
                    Style style = localStyleMap.get(name);
                    //更新
                    ArrayList<Style.AttrItem> items = style.items;
                    items.retainAll(attrs);
                    attrs.removeAll(items);//去掉本身存在的数据
                    attrs.addAll(items);//添加本地存在的数据
                    addStyleElement(attrs, resources, style.name, style.value);
                } else {
                    addStyleElement(attrs, resources, styleNames.get(i), i);
                }
            }
        } else {
            //重新插入
            for (int i = 0; i < size; i++) {
                addStyleElement(attrs, resources, styleNames.get(i), i);
            }
        }
        XmlUtils.writeXml(styleFile, document);
        System.out.println("style引用集更新完毕,耗时:" + (System.currentTimeMillis() - st));
    }

    /**
     * 获得主题引用
     *
     * @param styleFile
     */
    private static ArrayList<Style> getThemeStyle(File styleFile) {
        ArrayList<Style> styleAttrs = new ArrayList<>();
        if (styleFile.exists()) {
            SAXReader reader = new SAXReader();
            Document document;
            try {
                document = reader.read(styleFile);
                if (null != document) {
                    Element rootElement = document.getRootElement();
                    List<Element> elements = rootElement.elements();
                    elements.forEach(element -> {
                        Style style = new Style(element.attributeValue("name"), Integer.valueOf(element.attributeValue("value")));
                        styleAttrs.add(style);
                        List<Element> attrElements = element.elements();
                        attrElements.forEach(attrElement -> style.items.add(new Style.AttrItem(attrElement.attributeValue("name"), attrElement.attributeValue("value"))));
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return styleAttrs;
    }

    /**
     * 添加主题样式
     *
     * @param attrs
     * @param element
     * @param style
     * @param index
     */
    private static void addStyleElement(ArrayList<Style.AttrItem> attrs, Element element, String style, final int index) {
        Element styleElement = element.addElement("style");
        styleElement.addAttribute("name", style);
        styleElement.addAttribute("value", String.valueOf(index));
        attrs.forEach((attr) -> {
            Element attrElement = styleElement.addElement("attr");
            attrElement.addAttribute("name", attr.name);
            String value = "";
            if (0 == index) {
                value = attr.value;
            } else if (null != attr.value) {
                value = attr.value;
            }
            attrElement.addAttribute("value", value);
        });
    }

    /**
     * 生成更更新引用类
     *
     * @param attrs
     */
    public static void createOrUpdateAttrClass(File file, String packageName, ArrayList<Style.AttrItem> attrs, String time) {
        String attrName = file.getName();
        String className = attrName.substring(0, attrName.lastIndexOf("."));
        System.out.println("========================开始更新引用类========================");
        //获取原ThemeAttr文件,与当前合并
        ArrayList<Style.AttrItem> localAttrs = getThemeAttr(file);
        System.out.println("更新引用类,引用数量:" + attrs.size() + " 本地旧的引用数量:" + localAttrs.size());
        String themeAttrInfo;
        if (!localAttrs.isEmpty()) {
            ArrayList<Style.AttrItem> newAttrs = new ArrayList<>(attrs);
            newAttrs.removeAll(localAttrs);
            newAttrs.removeAll(attrs);
            //如果不为空,代码当前己有主题样式,更新
            //添加多余的引用条目
            System.out.println("插入引用:" + attrs.size() + " 新的引用:" + newAttrs.size());
            themeAttrInfo = getUpdateThemeAttrValue(packageName, attrs, newAttrs, getCommentInfos(file, time, newAttrs.size()), className);
        } else {
            themeAttrInfo = getCreateThemeAttrValue(packageName, attrs, time, className);
        }
        //写入字符
        try {
            FileWriter writer = new FileWriter(file);
            writer.write(themeAttrInfo);
            writer.close();
            System.out.println("更新引用类成功!");
        } catch (Exception e) {
        }
    }

    /**
     * 获得注释更新信息
     *
     * @param file
     * @param time
     * @param size
     * @return
     */
    private static ArrayList<String> getCommentInfos(File file, String time, int size) {
        ArrayList<String> commentInfos = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            Pattern pattern = Pattern.compile("(public\\s|)?(class|interface)\\s\\w+\\{");
            Pattern commentPattern = Pattern.compile("\\s\\*\\sCreated\\sby.+");
            Pattern updatePattern = Pattern.compile("\\s\\*\\s@update.+");
            String line;
            while (null != (line = reader.readLine())) {
                Matcher matcher = pattern.matcher(line);
                Matcher commentMatcher = commentPattern.matcher(line);
                Matcher updateMatcher = updatePattern.matcher(line);
                if (commentMatcher.find() || updateMatcher.find()) commentInfos.add(line + "\n");
                if (matcher.find()) {
                    commentInfos.add(" * @update " + time + " 更新:" + size + "条引用\n");
                    break;
                }
            }
            reader.close();
        } catch (Exception e) {
        }
        return commentInfos;
    }

    /**
     * 获得更新后的引用信息
     *
     * @param packageName
     * @param attrs
     * @param newAttrs
     * @param commentInfos
     */
    private static String getUpdateThemeAttrValue(String packageName, ArrayList<Style.AttrItem> attrs, ArrayList<Style.AttrItem> newAttrs, ArrayList<String> commentInfos, String className) {
        StringBuilder builder = new StringBuilder();
        //生成类信息
        builder.append("package " + packageName + ";\n");
        builder.append("\n");
        builder.append("/**\n");
        commentInfos.forEach(value -> builder.append(value));
        builder.append(" */\n");
        builder.append("public interface " + className + "{\n");

        attrs.forEach((item) -> {
            //生成class属性
            if (!newAttrs.contains(item.name)) {
                builder.append("\tString " + item.name.toUpperCase() + " = \"" + item.name + "\";\n");
            }
        });
        if (!newAttrs.isEmpty()) {
            //插入新的引用
            builder.append("\t//============更新后添加引用" + newAttrs.size() + "=================\n");
            for (Style.AttrItem attr : newAttrs) {
                builder.append("\tString " + attr.name.toUpperCase() + " = \"" + attr.name + "\";\n");
            }
        }
        builder.append("}\n");
        return builder.toString();
    }

    /**
     * 获得创建引用时的信息
     *
     * @param packageName
     * @param attrs
     * @param time
     * @return
     */
    private static String getCreateThemeAttrValue(String packageName, ArrayList<Style.AttrItem> attrs, String time, String className) {
        StringBuilder builder = new StringBuilder();
        builder.append("package " + packageName + ";\n");
        builder.append("\n");
        builder.append("/**\n");
        builder.append(" * Created by " + mConfig.author + " on " + time + ".\n");
        builder.append(" */\n");
        builder.append("public interface " + className + "{\n");
        attrs.forEach((item) -> {
            //生成class属性
//            String key = "";
            builder.append("\tString " + item.name.toUpperCase() + " = \"" + item.name + "\";\n");
        });
        builder.append("}\n");
        return builder.toString();
    }

    /**
     * 获得主题引用
     *
     * @param file
     */
    private static ArrayList<Style.AttrItem> getThemeAttr(File file) {
        ArrayList<Style.AttrItem> attrs = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            Pattern pattern = Pattern.compile("\\tString\\s(\\w+)\\s=\\s\"(\\w+)\"");
            while (null != (line = reader.readLine())) {
                Matcher matcher = pattern.matcher(line);
                if (matcher.find()) {
                    attrs.add(new Style.AttrItem(matcher.group(1).toLowerCase(), matcher.group(2)));
                }
            }
            reader.close();
        } catch (Exception e) {
        }
        return attrs;
    }

}
