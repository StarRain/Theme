package theme.read;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import theme.bean.AttrType;
import theme.bean.Style;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by cz on 15/8/9.
 * 样式引用读取
 */
public class StyleReader {

    /**
     * 读取style文件
     * @param file
     * @return
     */
    public static HashMap<Integer, Style> readStyles(File file) {
        final HashMap<Integer, Style> styles = new HashMap<>();
        SAXReader reader = new SAXReader();
        Document document;
        try {
            document = reader.read(file);
            if (null != document) {
                Element rootElement = document.getRootElement();
                List<Element> elements = rootElement.elements();
                final Pattern pattern = Pattern.compile("@(.+)/(.+)");
                elements.forEach(element -> {
                    String styleName = element.attributeValue("name");
                    int value = Integer.valueOf(element.attributeValue("value"));
                    Style style = new Style(styleName, value);
                    styles.put(value, style);
                    List<Element> childItems = element.elements();
                    childItems.forEach(childElement -> {
                        String attrName = childElement.attributeValue("name");
                        String attrValue = childElement.attributeValue("value");
                        Style.AttrItem item = new Style.AttrItem();
                        item.name = attrName;
                        Matcher matcher = pattern.matcher(attrValue);
                        if (matcher.find()) {
                            item.type = AttrType.getType(matcher.group(1));
                            item.value = matcher.group(2);
                        }
                        style.items.add(item);
                    });
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return styles;
    }

}
