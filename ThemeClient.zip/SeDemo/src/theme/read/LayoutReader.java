package theme.read;


import org.dom4j.Attribute;
import org.dom4j.Element;
import theme.bean.*;
import xml.XmlUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by cz on 15/8/8.
 * 布局解析器
 * 记录下以下节点
 * id/src/background/
 */
public class LayoutReader {

    /**
     * 解析layout xml文件
     *
     * @param file
     * @param drawableFilterAttrItems
     */
    public static ArrayList<StyleElement> readLayout(File file,
                                                     ArrayList<String> includeLayouts,
                                                     ArrayList<String> filterListViews,
                                                     HashMap<String, ArrayList<ListItem>> listItems,
                                                     HashMap<String, String> layoutIds,
                                                     TreeSet<DrawableFilterAttrItem.FilterAttrItem> drawableFilterAttrItems,
                                                     HashMap<String, ArrayList<ViewInfo>> viewInfos) {
        return XmlUtils.parserXml(file, (int index, Element element, List<Attribute> attributes) -> {
            StyleElement styleElement = null;
            if (null != attributes && !attributes.isEmpty()) {
                styleElement = new StyleElement();
                String elementName = element.getName();
                styleElement.view = elementName;

                //自定义控件简称
                int i = elementName.lastIndexOf(".");
                String viewName = elementName;
                if (-1 != i) {
                    viewName = elementName.substring(i + 1);
                }

                String fileName = file.getName();
                fileName = fileName.substring(0, fileName.indexOf("."));
                //记录所有自定义控件
                if (-1 != elementName.indexOf(".")) {
                    ArrayList<ViewInfo> infos = viewInfos.get(fileName);
                    if (null == infos) {
                        infos = new ArrayList<>();
                        viewInfos.put(fileName, infos);
                    }
                    String id = element.attributeValue("id");
                    if (null != id) {
                        Pattern compile = Pattern.compile("@(id|\\+id)/(\\w+)");
                        Matcher matcher = compile.matcher(id);
                        if (matcher.find()) {
                            infos.add(new ViewInfo(viewName, matcher.group(2)));
                        }
                    }
                }
                //检测是否为列表控件如/ListView/RecyclerView等,目前只统计ListView/RecyclerView
                //处理带包名的自定义列表
                if (filterListViews.contains(viewName)) {
                    //列表相当于一个控制集,单独定义一个xml来初始化
                    String id = element.attributeValue("id");
                    ArrayList<ListItem> items = listItems.get(fileName);
                    if (null == items) {
                        items = new ArrayList<>();
                        listItems.put(fileName, items);
                    }
                    Pattern compile = Pattern.compile("@(id|\\+id)/(\\w+)");
                    Matcher matcher = compile.matcher(id);
                    if (matcher.find()) {
                        items.add(new ListItem(viewName, matcher.group(2)));
                    }
                } else if ("include".equals(viewName)) {
                    //如果是一个include标签,记录布局与include关系
                    String layout = element.attributeValue("layout");
                    Pattern compile = Pattern.compile("@layout/(\\w+)");
                    Matcher matcher = compile.matcher(layout);
                    if (matcher.find()) {
                        String layoutValue = matcher.group(1);
                        includeLayouts.add(fileName + "|" + layoutValue);
                    }
                }

                int size = attributes.size();
                Pattern compile = Pattern.compile("(@\\+|@|\\?)(.+)/(.+)");
                for (i = 0; i < size; i++) {
                    Attribute attribute = attributes.get(i);
                    String attrName = attribute.getName();
                    String attrValue = attribute.getValue();
                    //反向以值确定属性
                    if (attrValue.matches("(\\?|@).+/.+")) {
                        //获得引用类型
                        Matcher matcher = compile.matcher(attrValue);
                        if (matcher.find()) {
                            int count = matcher.groupCount();
                            if (3 <= count) {
                                String type = matcher.group(2);
                                String value = matcher.group(3);
                                if ("id".equals(attrName)) {
                                    styleElement.id = value;
                                    //记录layout名称与首个节点id映射关系
                                    if (0 == index) {
                                        layoutIds.put(fileName, value);
                                    }
                                } else if ("color".equals(type)) {
                                    styleElement.items.add(new StyleElement.Element(ResType.getType(attrName).value, type, value, attrValue));
                                } else if ("drawable".equals(type)) {
                                    //是否为drawable过滤对象
                                    if (value.endsWith("_filter")) {
                                        attrName += "Filter";//标记为drawable过滤操作
                                        //添加颜色过滤引用
                                        drawableFilterAttrItems.add(new DrawableFilterAttrItem.FilterAttrItem(value));
                                    }
                                    styleElement.items.add(new StyleElement.Element(ResType.getType(attrName).value, type, value, attrValue));
                                }
                            }
                        }
                    }
                }
                //丢弃掉无用的view
                //1:无id的控件 2:无color/drawable外的属性
                if (null == styleElement.id || styleElement.items.isEmpty()) {
                    styleElement = null;
                }
            }
            return styleElement;
        });
    }
}
