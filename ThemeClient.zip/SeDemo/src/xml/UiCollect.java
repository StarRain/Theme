package xml;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import java.io.File;
import java.io.FileWriter;
import java.util.*;

/**
 * 维护ui维护xml
 * 
 * @author cz 2015/6/29
 */
public class UiCollect {
	public static void main(String[] args) {
		// outPckDirectory(
		// new File(
		// "/Users/cz/Desktop/master/wxrd_v1.10/weixinredian/src/main/java/com/weishang/wxrd"),
		// "Fragment", "Activity");
		// 解析现有xml内容
		File file = new File(
				"/Users/cz/Desktop/master/wxrd_v1.10/weixinredian/src/main/assets/config/collect_config.xml");
		ArrayList<UmengItem> parserItems = parserXml(file);
		
		// 扫描新的值
		ArrayList<UmengItem> allItems = getAllUmengItems(new File(
						"/Users/cz/Desktop/master/wxrd_v1.10/weixinredian/src/main/java/com/weishang/wxrd"),
				"Fragment", "Activity");
		System.out.println("before:" + allItems.size() + " removeItem:"
				+ parserItems.size());
		

		// 测试打印无效条目数-------------------------
		ArrayList<UmengItem> invalidItem = new ArrayList<UmengItem>();
		int size = parserItems.size();
		for (int i = 0; i < size; i++) {
			UmengItem umengItem = parserItems.get(i);
			if (!allItems.contains(umengItem)) {
				invalidItem.add(umengItem);
			}
		}
		
		// 创建新的文件
		allItems.removeAll(parserItems);

		// 移除无效条目
		parserItems.removeAll(invalidItem);

		 System.out.println("invalidItem:"+invalidItem.size());
		// item invalidItem:11

		System.out.println("after:" + allItems.size());
		// for (UmengItem item : allItems) {
		// System.out.println(item);
		// }
		
		//写入xml
		write2Xml(file,allItems,parserItems,invalidItem);

	}

	public static ArrayList<UmengItem> parserXml(File file) {
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(file);
		} catch (DocumentException e) {
			e.printStackTrace();
		}
		// 获取到初始的值
		ArrayList<UmengItem> umengItems = new ArrayList<UmengItem>();
		if (null != document) {
			Element rootElm = document.getRootElement();
			Element element = rootElm.element("ui");
			List<Element> itemElements = element.elements();
			for (Iterator<Element> it = itemElements.iterator(); it.hasNext();) {
				Element elm = it.next();
				String clazz = elm.attributeValue("class");
				String name = elm.attributeValue("name");
				String exclude = elm.attributeValue("exclude");
				UmengItem umengItem = new UmengItem(clazz, name,
						Boolean.valueOf(exclude));
				umengItems.add(umengItem);
				List<Element> elements = elm.elements();
				if (null != elements && !elements.isEmpty()) {
					for (Element childElement : elements) {
						umengItem.childs.add(new UmengItem.Item(childElement
								.attributeValue("catid"), childElement
								.attributeValue("name")));
					}
				}
			}
		}
		return umengItems;
	}

	/**
	 * 生成指定文字包含全路径.
	 */
	public static ArrayList<UmengItem> getAllUmengItems(File file,
			String... names) {
		// /Users/cz/Desktop/master/wxrd_v1.10/weixinredian/src/main/java/com/weishang/wxrd
		ArrayList<UmengItem> umengItems = new ArrayList<UmengItem>();
		if (file.isDirectory()) {
			List<String> filterNames = Arrays.asList(names);
			LinkedList<File> files = new LinkedList<>();
			files.add(file);
			while (!files.isEmpty()) {
				File temp = files.removeFirst();
				if (temp.isDirectory()) {
					File[] listFiles = temp.listFiles();
					if (null != listFiles) {
						files.addAll(Arrays.asList(listFiles));
					}
				} else {
					boolean result = false;
					String name = temp.getName();
					for (String fliter : filterNames) {
						if (name.contains(fliter)) {
							result = true;
							continue;
						}
					}
					if (result) {
						umengItems.add(new UmengItem(getFilePackage(temp)));
					}
				}
			}
		}
		return umengItems;
	}

	private static String getFilePackage(File temp) {
		String path = temp.getAbsolutePath();
		path = path.replaceAll("/", ".");// 去掉反斜
		int index = path.indexOf("com");
		path = path.substring(index);
		if (path.endsWith(".java")) {
			path = path.replace(".java", "");
		}
		return path;
	}

	/**
	 * 生成xml
	 * 
	 * @param newItems
	 *            新添加的条目
	 * @param items
	 *            之前存在的条目数
	 * @param invalidItems
	 *            无效或移除的条目/待用户确认
	 */
	public static void write2Xml(File file, ArrayList<UmengItem> newItems,
			ArrayList<UmengItem> items, ArrayList<UmengItem> invalidItems) {
		// dom4j解析xml测试

		// 1. dom4j写xml
		Document document = DocumentHelper.createDocument();
		Element root = document.addElement("collect");

		Element uiElement = root.addElement("ui");
		// 添加原来对象
		int size = items.size();
		for (int i = 0; i < size; i++) {
			UmengItem item = items.get(i);
			if (0 == i) {
				uiElement
						.addComment("===================更新前item列表==================");
			}
			Element itemElement = uiElement.addElement("item");
			itemElement.addAttribute("class", item.clazz);
			itemElement
					.addAttribute("name", null != item.name ? item.name : "");
			if(item.exclude){
				itemElement.addAttribute("exclude", String.valueOf(item.exclude));
			}
			if (null != item.childs && !item.childs.isEmpty()) {
				int childSize = item.childs.size();
				for (int j = 0; j < childSize; j++) {
					UmengItem.Item childItem = item.childs.get(j);
					Element childElement = itemElement.addElement("child");
					childElement.addAttribute("catid", childItem.catid);
					childElement.addAttribute("name", childItem.name);
				}
			}
		}

		// 添加无效对象
		size = invalidItems.size();
		for (int i = 0; i < size; i++) {
			UmengItem item = invalidItems.get(i);
			if (0 == i) {
				uiElement
						.addComment("===================更新前item列表的无效对象==================");
			}
			Element itemElement = uiElement.addElement("item");
			itemElement.addAttribute("class", item.clazz);
			itemElement
					.addAttribute("name", null != item.name ? item.name : "");
			if(item.exclude){
				itemElement.addAttribute("exclude", String.valueOf(item.exclude));
			}
		}
		
		//添加新加入对象
		size = newItems.size();
		for (int i = 0; i < size; i++) {
			UmengItem item = newItems.get(i);
			if (0 == i) {
				uiElement
						.addComment("===================新添加列表对象==================");
			}
			Element itemElement = uiElement.addElement("item");
			itemElement.addAttribute("class", item.clazz);
			itemElement
					.addAttribute("name","");
			if(item.exclude){
				itemElement.addAttribute("exclude", String.valueOf(item.exclude));
			}
			
		}
		
		
		try {
			/** 将document中的内容写入文件中 */
			XMLWriter writer = new XMLWriter(new FileWriter(file));
			writer.write(document);
			writer.close();
			/** 执行成功,需返回1 */
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		System.out.println("写入成功");

	}

}
