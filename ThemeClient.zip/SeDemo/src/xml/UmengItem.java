package xml;

import java.util.ArrayList;

/**
 * 友盟统计item
 * 
 * @author cz
 * @time 2015/6/29
 */
public class UmengItem {
	public String clazz;// 统计类引用名
	public String name;// 界面名称
	public boolean exclude;// 统计标记
	public ArrayList<Item> childs;
	
	

	public UmengItem(String clazz) {
		super();
		this.clazz = clazz;
	}

	public UmengItem(String clazz, String name, boolean exclude) {
		super();
		this.clazz = clazz;
		this.name = name;
		this.exclude = exclude;
		childs = new ArrayList<Item>();
	}

	public static class Item {
		public String catid;
		public String name;

		public Item(String catid, String name) {
			this.catid = catid;
			this.name = name;
		}
	}

	@Override
	public boolean equals(Object obj) {
		boolean result = false;
		if (obj instanceof UmengItem) {
			UmengItem item=(UmengItem) obj;
			result = clazz.equals(item.clazz);
//			System.out.println("clazz:"+clazz+" item:"+item.clazz);
		}
		return result;
	}
	
	@Override
	public String toString() {
		return "class:"+clazz+" name:"+name;
	}
}
