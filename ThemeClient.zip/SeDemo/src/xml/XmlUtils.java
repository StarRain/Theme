package xml;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by cz on 15/8/8.
 * xml解析工具
 */
public class XmlUtils {

    /**
     * 解析xml对象
     *
     * @param file
     * @return
     */
    public static <T> ArrayList<T> parserXml(File file, OnParserListener<T> listener) {
        SAXReader reader = new SAXReader();
        Document document;
        ArrayList<T> items = null;
        try {
            items = new ArrayList<>();
            document = reader.read(file);
            if (null != document) {
                ArrayList<Element> elements = getElements(document.getRootElement());
                for(int i=0;i<elements.size();i++){
                    Element element = elements.get(i);
                    //解析item
                    Object object = listener.parser(i,element, element.attributes());
                    if (null != object) {
                        items.add((T) object);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return items;
    }

    /**
     * 获得Element节点内所有节点
     *
     * @param root
     * @return
     */
    private static ArrayList<Element> getElements(Element root) {
        ArrayList<Element> allElements = new ArrayList<>();
        LinkedList<Element> elements = new LinkedList<>();
        allElements.add(root);
        elements.add(root);
        while (!elements.isEmpty()) {
            Element element = elements.removeFirst();
            List<Element> es = element.elements();
            if (null != es && !es.isEmpty()) {
                allElements.addAll(es);
                elements.addAll(es);
            }
        }
        return allElements;
    }


    /**
     * 写入document对象到xml
     */
    public static <T> void writeXml(File file, Document document) {
        try {
            XMLWriter writer = new XMLWriter(new FileWriter(file));// 将document中的内容写入文件中
            writer.write(document);
            writer.close();
            System.out.println("写入成功");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * 解析xml
     */
    public interface OnParserListener<T> {
        T parser(int index,Element element, List<Attribute> attributes);
    }
}
