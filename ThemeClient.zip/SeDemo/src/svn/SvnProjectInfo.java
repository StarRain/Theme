package svn;

import java.io.*;

/**
 * Created by cz on 15/8/1.
 * svn 提交日志查看
 */
public class SvnProjectInfo {
    public static void main(String[] args) {
        try {
            Runtime runtime = Runtime.getRuntime();
            Process process = runtime.exec("svn log https://192.168.1.200/svn/3jyapp/studio/wxrd_v1.10 -r {2015-7-27}:{2015-7-29}");
            System.out.print(loadStream(process.getInputStream()));
//            System.err.print(loadStream(process.getErrorStream()));
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    static String loadStream(InputStream in) throws IOException {
        in = new BufferedInputStream(in);
        StringBuffer buffer = new StringBuffer();
        int count;
        byte[] bys = new byte[10 * 1024];
        File outFile=new File("/Users/cz/desktop/a.txt");
        System.out.println("文件:"+outFile.exists());
        BufferedWriter fileWriter =null;
        try{
             fileWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outFile), "UTF-8"));
            while (-1 != (count = in.read(bys))) {
                fileWriter.write(new String(bys,0,count,"utf-8"));
            }
            fileWriter.close();
        } catch (Exception e){
        }
        return buffer.toString();
    }
}
