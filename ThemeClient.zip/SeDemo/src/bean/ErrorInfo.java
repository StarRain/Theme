package bean;

/**
 * Created by cz on 15/8/16.
 * 关注异常信息
 */
public class ErrorInfo {
    //    "id", "account", "name", "type", "ct", "step", "remark"
    public String id;
    public String account;
    public String name;
    public int type;
    public long ct;
    public int step;
    public String remark;

}
