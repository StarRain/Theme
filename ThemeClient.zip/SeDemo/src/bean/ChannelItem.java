package bean;

/**
 * Created by cz on 15/8/27.
 */
public class ChannelItem {
    public int id;
    public String name;
    public String image;
    public String type;
    public String bookcount;//订阅状态
    public boolean subscribe;//是否订阅
    public int itemType;//条目类型

}
