package bean;

import java.util.LinkedList;

/**
 * Created by cz on 15/8/12.
 */
public class Template {
    public String action;
    public String info;
    public String modelValue;//数据模型值
    public LinkedList<Step> steps;
    public int start;//开始循环步数
    public int end;//结束循环步数
}
