package bean;

public class StyleElement {

    public String id;
    public String view;
    public String attrs;
    public String types;
}