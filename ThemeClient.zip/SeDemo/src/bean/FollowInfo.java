package bean;

/**
 * Created by cz on 15/8/16.
 * 关注信息
 */
public class FollowInfo {
    public String action;
    public String info;
    public String checkAccount;
    public String errorAccount;
    public long startTime;
    public long endTime;
    public int total;
    public int errorCount;
    public String remark;
}
