package bean;

/**
 * Created by cz on 15/8/12.
 */
public class Step {
    public int step;//所属模板第几步
    public String info;//步骤介绍信息
    public String value;//操作对象值
    public String data;//对象取值
    public int menu;//所在actionbar位置
    public boolean isParent;//是否为父节点
    public String predicateValue;//对象设置检测
}
