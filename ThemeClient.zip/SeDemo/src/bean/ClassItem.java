package bean;

import java.util.ArrayList;

/**
 * Created by cz on 15/9/17.
 */
public class ClassItem {
    public String name;
    public final ArrayList<FieldItem> fieldItems;

    public ClassItem(String name) {
        this.name = name;
        fieldItems = new ArrayList<>();
    }

    public static class FieldItem {
        public String name;
        public String type;
        public String value;
    }
}
