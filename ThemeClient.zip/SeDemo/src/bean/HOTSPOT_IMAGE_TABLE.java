package bean;
/**
* create by cz 2015/09/16;
*/
public class HOTSPOT_IMAGE_TABLE {
	public int _id;
	public int id;
	public String pic;
	public String url;
	public int width;
	public int height;
	public int class_id;
	public String url_type;
	public String name;
	public int link_id;
	public String android_address;
}
