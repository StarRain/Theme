package bean;

/**
 * Created by cz on 15/9/17.
 */
public enum  FieldType {
}
