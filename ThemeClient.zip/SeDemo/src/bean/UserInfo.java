package bean;

/**
 * Created by cz on 15/8/1.
 */
public class UserInfo {
    public String uid;
    public String score;
    public String invite_code;
    public int is_blocked;
    public int is_invited;
    public String mobile;
    public String gender;
    public String nickname;
    public String avatar;
    public int phone_status;
    public int sina_status;
    public int qq_status;
    public int wx_status;
}
