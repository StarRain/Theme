package bean;

/**
 * Created by cz on 15/8/11.
 * 公众号信息
 */
public class Account {
    public int id;
    public String account;
    public String name;
    public int level;
    public long ct;
    public long ut;
    public String result;
}
