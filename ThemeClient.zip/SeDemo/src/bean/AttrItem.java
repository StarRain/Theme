package bean;

public class AttrItem {
    public String name;
    public String value;

    public AttrItem() {
    }
}