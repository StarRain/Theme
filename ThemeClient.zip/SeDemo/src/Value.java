/**
 * Created by cz on 15/7/7.
 */
public class Value<V> {
    private V v;

    public Value(V v) {
        this.v = v;
    }
}
