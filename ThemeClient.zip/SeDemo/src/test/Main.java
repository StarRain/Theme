package test;

public class Main<T> {

    public static void main(String[] args){
        Main main1 = new Main();
        Main main2 = new Main();
        Main main3 = new Main();
        System.out.println("main1:"+main1);
        System.out.println("main2:"+main2);
        System.out.println("main3:"+main3);
    }

}
