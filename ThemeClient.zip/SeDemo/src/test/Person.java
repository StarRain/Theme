package test;

/**
 * Created by cz on 15/7/15.
 */
public class Person {
    public String name;
    public int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public int hashCode() {
        return age;
    }

    @Override
    public boolean equals(Object obj) {
        boolean result=false;
        if(obj instanceof Person){
            Person obj1 = (Person) obj;
            result=age==obj1.age;
        }
        return result;
    }
}
