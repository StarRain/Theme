package test;


import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TreeDemo3 {
    public TreeDemo3() {
        // 设置成Alloy界面样式
            JFrame.setDefaultLookAndFeelDecorated(true);
        // this line needs to be implemented in order to make JWS work properly

        // JDialog.setDefaultLookAndFeelDecorated(true);
        JFrame f = new JFrame("firstTree");

        Container contentPane = f.getContentPane();
        // if (contentPane instanceof JComponent) {
        // ((JComponent) contentPane).setMinimumSize(new Dimension(100, 100));
        // }
        // Container contentPane = f.getContentPane();

        DefaultMutableTreeNode root = new DefaultMutableTreeNode("资源管理器");
        DefaultMutableTreeNode node1 = new DefaultMutableTreeNode("我的公文包");
        DefaultMutableTreeNode node2 = new DefaultMutableTreeNode("我的电脑");
        DefaultMutableTreeNode node3 = new DefaultMutableTreeNode("收藏夹");
        DefaultMutableTreeNode node4 = new DefaultMutableTreeNode("Readme");

        DefaultTreeModel treeModel = new DefaultTreeModel(root);
        root.add(node1);
        root.add(node2);
        root.add(node3);
        root.add(node4);

        node1.add(new DefaultMutableTreeNode("公司文件"));
        node1.add(new DefaultMutableTreeNode("个人信件"));
        node1.add(new DefaultMutableTreeNode("私人文件"));

        node2.add(new DefaultMutableTreeNode("本机磁盘(C:)"));
        node2.add(new DefaultMutableTreeNode("本机磁盘(D:)"));
        node2.add(new DefaultMutableTreeNode("本机磁盘(E:)"));



        node3.add(new DefaultMutableTreeNode("网站列表"));
        node3.add(new DefaultMutableTreeNode("奇摩站"));
        node3.add(new DefaultMutableTreeNode("职棒消息"));
        node3.add(new DefaultMutableTreeNode("网络书店"));


        JTree tree = new JTree(treeModel);
		/* 改变JTree的外观* */
        // tree.putClientProperty("JTree.lineStyle","Horizontal");
		/* 改变JTree的外观* */
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setViewportView(tree);

        contentPane.add(scrollPane);
        f.pack();
        f.setVisible(true);

        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

    }

    public static void main(String args[]) {

        new TreeDemo3();
    }
}


