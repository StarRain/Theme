package test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by cz on 15/9/9.
 */
public class PatternTest {

    /**
     * 测试正则
     *
     * @param regex
     * @param value
     */
    public static void matcher(String regex, String value) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(value);
        System.out.println("======matcher======");
        if (matcher.find()) {
            int count = matcher.groupCount();
            if (0 == count) {
                System.out.println(matcher.group());
            } else {
                System.out.println("group:" + count);
                for (int i = 0; i <= count; i++) {
                    System.out.print(matcher.group(i) + " ");
                }
                System.out.println();
            }
        }
    }
}
