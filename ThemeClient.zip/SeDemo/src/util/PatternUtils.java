package util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by cz on 15/9/13.
 */
public class PatternUtils {
    /**
     * 匹配正则
     *
     * @param regex
     */
    public static void matcher(String regex, String target) {
        Pattern compile = Pattern.compile(regex);
        Matcher matcher = compile.matcher(target);
        if (matcher.find()) {
            int count = matcher.groupCount();
            if (1 < count) {
                for (int i = 0; i <= count; i++) {
                    System.out.println("group:" + matcher.group(i));
                }
            } else {
                System.out.println(matcher.group());
            }
        }
    }
}
