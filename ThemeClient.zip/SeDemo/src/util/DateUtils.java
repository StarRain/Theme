package util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * 时间工具类
 *
 * @author momo
 * @Date 2014/6/4
 */
public class DateUtils {
    public static final int MINUTES = 60 * 1000;// 分毫秒值
    public static final int HOUR = 60 * MINUTES;// 小时毫秒值
    public static final int DAY = 24 * HOUR;// 天毫秒值
    public static final int WEEK = 7 * DAY;// 周毫秒值

    /**
     * 格式化进度信息
     *
     * @param duration 时间数
     * @return
     */
    public static String getProgressTime(long duration) {
        return getFromat("mm:ss", duration);
    }

    public static String getFormatTime(long duration) {
        return getFromat("MM天dd日 hh:mm:ss", duration);
    }

    /**
     * 格式化时间值
     *
     * @param format   格化
     * @param duration 时间值
     * @return
     */
    public static String getFromat(String format, long duration) {
        return new SimpleDateFormat(format).format(duration);
    }

    /**
     * 根据给定时区字符串值,返回当前时间毫秒
     */
    public static long getTimeMillis(String createTime) {
        DateFormat formater = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        try {
            return formater.parse(createTime).getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return -1;
    }

}
