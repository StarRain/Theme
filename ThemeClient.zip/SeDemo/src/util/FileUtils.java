package util;

import java.io.File;
import java.util.Arrays;
import java.util.LinkedList;

/**
 * Created by cz on 15/9/9.
 * 文件工具类
 */
public class FileUtils {

    /**
     * 遍历文件操作
     *
     * @param file
     * @param listener
     */
    public static <T> T scanFile(File file, ScanListener<File> listener) {
        LinkedList<File> files = new LinkedList<>();
        files.add(file);
        while (files.size() > 0) {
            File f = files.removeFirst();
            if (f.isDirectory()) {
                File[] listFiles = f.listFiles();
                if (null != listFiles && 0 < listFiles.length) {
                    files.addAll(Arrays.asList(listFiles));
                }
            } else if (null != listener) {
                listener.scan(f);
            }
        }
        T t = null;
        if (null != listener) {
            t = listener.result();
        }
        return t;
    }

    /**
     * 扫措监听
     *
     * @param <E>
     */
    public interface ScanListener<E> {
        void scan(E e);

        <T> T result();
    }
}
