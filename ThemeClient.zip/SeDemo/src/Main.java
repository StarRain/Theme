import bean.ClassItem;
import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import test.PatternTest;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main<T> {

    public static void main(String[] args) {
//        String filedTarget="R.id.abd;";
//        String target = "view.setText(R.string.ok);  view.setImageDrawable(R.drawable.ic_lancher); file=R.attr.okbsd;";
//        Pattern p = Pattern.compile("\\((R\\.(string|drawable)\\.(.+?))\\)");
//        Pattern p2 = Pattern.compile("((R\\.(id|string|drawable|attr|color|array|styleable)\\.(\\w*))|(0[xX][a-fA-F0-9]{6,8}))");
//        Pattern javaPattern = Pattern.compile("(R\\.(id|string|drawable|attr|color|array|styleable)\\.(\\w*))");
//        Pattern p2 = Pattern.compile("((@(attr|string|drawable|color|array)/\\w*)|(\\?attr/\\w*)|(#[a-fA-F0-9]*))");
//        Matcher m = javaPattern.matcher(target);
//        while (m.find()) {
//            System.out.println("value:"+m.group());
//        }
//        File file=new File("/Users/cz/Desktop/activity_login.xml");
//        parserXml(file);
//        String target="-1|-1|21457|-1|-1|-1|-1|-1|1436859161752|-1|1|-1|-1|-1|-1|-1|-1|-1|-1|1|-1|9d3851d33ddf49f9|-1|-1|1|-1|-1|1|-1|-1|-1|-1|-1|1436500919|600|-1|11|1|-1|-1|-1|-1|-1|-1|-1|43200000|-1|1.4.0|http://www.weixinkd.com|1436859158808|{\"wall_ad\":\"1\",\"filter_ad\":[],\"top_flowad\":\"0\",\"banner_ad\":\"1\",\"flowad\":\"1\",\"screen_ad\":\"0\",\"cat_flowad\":\"0\",\"content_ad\":\"1\",\"channel\":[\"c1081\"],\"pos\":\"3\"}|-1|-1|-1|140|-1|{\"url\":\"http://www.jd.com\",\"title\":\"别墅\",\"thumb\":\"http://p2.pstatp.com/origin/6040/4783145234\",\"display_after\":0,\"leave_interval\":600,\"skip_btn\":1,\"id\":18,\"display_type\":1,\"display_time\":3,\"image_type\":3}|1436859158827";
//        System.out.println(target.split("\\|")[47]);


//        Random random=new Random();
//        ArrayList<Person> persons=new ArrayList<Person>();
//        for(int i=0;i<10;i++){
//            int age = random.nextInt(2);
//            persons.add(new Person("namme:"+age,age));
//        }
//
//        TreeSet<Person> allPerson=new TreeSet<Person>(new Comparator<Person>() {
//            @Override
//            public int compare(Person o1, Person o2) {
//                return 0;
//            }
//        });
//        for(int i=0;i<10;i++){
//            if(!allPerson.add(persons.get(i))){
//                System.out.println("添加失败,重复出现");
//            }
//        }
//        System.out.println(allPerson.size());

        //获取信息,
        // 1:java 所在包
        // 1:java 导入包列表
        // 1:java 类信息 private public default 类/class/enum/interface/@interface implements/extends class
        // 1:java 字段/方法  //静态方法


//        /Users/cz/IdeaProjects/SeDemo/src/theme/bean/LayoutMapped.java
//        /Users/cz/IdeaProjects/SeDemo/src/theme/bean/AttrType.java

        //流获取文本
        //正则分析


//        try {

        //正则分析
//          package theme.bean;
//            String packageRegex = "package\\s([\\w\\.]+);";
//          import java.util.ArrayList;
//            String importRegex = "(import|import static)\\s([\\w\\.]+);";
        //public class LayoutMapped {

//            String classRegex = "(private|public)?\\s*(static|static final)?\\s*(class|interface|enum|@interface)\\s(\\w+)\\s*\\{";

//            String filedRegex = "(private|public)?\\s(static|static final)\\s(\\w+)\\s(\\w+)\\w*(=\\w+)?;";


//            PatternUtils.matcher(packageRegex,"package theme.bean;");
//            PatternUtils.matcher(importRegex,"import java.util.ArrayList;");
//            PatternUtils.matcher(importRegex,"import static java.util.LinkedList;");
//            PatternUtils.matcher(classRegex, "class A{");
//            PatternUtils.matcher(classRegex, "public class B {");
//            PatternUtils.matcher(classRegex, "private static class C {");


//            BufferedReader reader = new BufferedReader(new FileReader(new File("/Users/cz/IdeaProjects/SeDemo/src/theme/bean/LayoutMapped.java")));
//            String line;
//            while (null != (line = reader.readLine())) {
//                System.out.println(line);
//            }
//            reader.close();
//        } catch (Exception e) {
//        }
//        String target="drawable_abc";
//        System.out.println(target.substring(0,target.indexOf("_")));

//        createClassFromSql();

        String value="{\"success\":true,\"error_code\":\"0\",\"message\":\"\\u8fd4\\u56de\\u6210\\u529f\",\"items\":[{\"input_time\":\"1442564006\",\"mid\":\"0\",\"idx\":\"0\",\"account_id\":\"5628\",\"title\":\"\\u65b0\\u5341\\u5927\\u50bb\\uff0c\\u4f60\\u5728\\u5185\\u5417\\uff1f \",\"id\":\"4561683\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_09_094_55efddf117800.jpg\",\"wurl\":\"\",\"url\":\"\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"1\",\"muti_list\":[{\"input_time\":\"1442563939\",\"mid\":\"0\",\"idx\":\"0\",\"account_id\":\"5628\",\"title\":\"\\u4f60\\u4eba\\u518d\\u597d\\u6709\\u5c41\\u7528 \\u2014\\u2014 \\u81f4\\u81ea\\u5df1 \",\"id\":\"4561667\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_189_55fbc76331155.jpg\",\"wurl\":\"\",\"url\":\"\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\"},{\"input_time\":\"1442563883\",\"mid\":\"0\",\"idx\":\"0\",\"account_id\":\"5628\",\"title\":\"\\u5973\\u4eba\\uff0c\\u5c31\\u8981\\u62fd\\u4e00\\u70b9\\uff01 \",\"id\":\"4561652\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18g_55fbc72b82f04.jpg\",\"wurl\":\"\",\"url\":\"\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\"},{\"input_time\":\"1442563297\",\"mid\":\"0\",\"idx\":\"0\",\"account_id\":\"5628\",\"title\":\"\\u4ec0\\u4e48\\u53eb\\u505a\\u591a\\u4f59\\uff1f \\uff08\\u5efa\\u8bae\\u90fd\\u770b\\u770b\\uff09 \",\"id\":\"4561224\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18y_55fbc4e1936ef.jpg\",\"wurl\":\"\",\"url\":\"\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\"}],\"oid\":\"1442564006\"},{\"input_time\":\"1442563564\",\"mid\":\"9197537\",\"idx\":\"6\",\"account_id\":\"5628\",\"title\":\"\\u5982\\u679c\\u505c\\u6b62\\u8fdb\\u98df\\uff0c\\u8eab\\u4f53\\u4f1a\\u6162\\u6162\\u300c\\u5403\\u300d\\u6389\\u81ea\\u5df1\",\"id\":\"4561665\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18n_55fb810cc6325.jpg\",\"wurl\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=11981855791669026501&cid=472933935&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=15365463206561322086&readId=1db6619ea3a7ada9b9153ed0292096ec&rd_type=reco\",\"url\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=11981855791669026501&cid=472933935&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=15365463206561322086&readId=1db6619ea3a7ada9b9153ed0292096ec&rd_type=reco\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442563564\"},{\"input_time\":\"1442563564\",\"mid\":\"9197538\",\"idx\":\"7\",\"account_id\":\"5628\",\"title\":\"\\u65e9\\u8d77\\u7a7a\\u8179\\u8dd1\\u6b65\\uff0c\\u8d8a\\u8dd1\\u8d8a\\u80d6\\u8fd8\\u6709\\u751f\\u547d\\u5371\\u9669\\uff01\",\"id\":\"4561664\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_184_55fbc753e9de9.jpg\",\"wurl\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=15103195888057316244&cid=472933935&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=5510666185039548383&readId=1a5995c54a114012cd381bfe889960f6&rd_type=reco\",\"url\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=15103195888057316244&cid=472933935&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=5510666185039548383&readId=1a5995c54a114012cd381bfe889960f6&rd_type=reco\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442563564\"},{\"input_time\":\"1442563564\",\"mid\":\"9197536\",\"idx\":\"7\",\"account_id\":\"5628\",\"title\":\"\\u5168\\u7403\\u516c\\u8ba4\\u6700\\u5065\\u5eb7\\u7684\\u4f5c\\u606f\\u65f6\\u95f4\\u8868\\uff01\\u53f2\\u4e0a\\u6700\\u840c\\u7248\\u7684\\u5466\\uff01\",\"id\":\"4561668\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18l_55fbc77795064.jpg\",\"wurl\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=13646543129887347954&cid=472933935&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=15365463206561322086&readId=566b8d133fc865f73639f46828f6f729&rd_type=reco\",\"url\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=13646543129887347954&cid=472933935&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=15365463206561322086&readId=566b8d133fc865f73639f46828f6f729&rd_type=reco\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442563564\"},{\"input_time\":\"1442563564\",\"mid\":\"9197539\",\"idx\":\"9\",\"account_id\":\"5628\",\"title\":\"\\u505a\\u8fd9\\u5341\\u4ef6\\u4e8b\\u582a\\u6bd4\\u81ea\\u6740\",\"id\":\"4561663\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_189_55fbc75245b21.jpg\",\"wurl\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=1765528234400687559&cid=472933935&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=5510666185039548383&readId=59ce3f26bc336ca8e9f4b596ead5ae96&rd_type=reco\",\"url\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=1765528234400687559&cid=472933935&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=5510666185039548383&readId=59ce3f26bc336ca8e9f4b596ead5ae96&rd_type=reco\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442563564\"},{\"input_time\":\"1442563219\",\"mid\":\"42564105\",\"idx\":\"3\",\"account_id\":\"5628\",\"title\":\"\\u8fd9\\u6b3e\\u8d5b\\u8f66\\u670d\\u8981\\u89e3\\u51b3\\u6469\\u6258\\u8f66\\u7231\\u597d\\u8005\\u7684\\u75db\\u70b9\",\"id\":\"4561727\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18s_55fbc80585bd7.jpg\",\"wurl\":\"http:\\/\\/toutiao.com\\/a6195757716260536578\\/?iid=2927750443&app=news_article\",\"url\":\"http:\\/\\/toutiao.com\\/a6195757716260536578\\/?iid=2927750443&app=news_article\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442563219\"},{\"input_time\":\"1442563158\",\"mid\":\"638458125\",\"idx\":\"9\",\"account_id\":\"5628\",\"title\":\"\\u5343\\u5143\\u4ee5\\u4e0b\\u6027\\u4ef7\\u6bd4\\u624b\\u673a\\u63a8\\u8350\\uff1a\\u9002\\u5408\\u81ea\\u5df1\\u5b9e\\u7528\\u5b9e\\u60e0\\u624d\\u662f\\u738b\\u9053\\uff01\",\"id\":\"4561651\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18v_55fbc71ff2f08.jpg\",\"wurl\":\"http:\\/\\/toutiao.com\\/a6195757381252612353\\/?iid=2927750443&app=news_article\",\"url\":\"http:\\/\\/toutiao.com\\/a6195757381252612353\\/?iid=2927750443&app=news_article\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442563158\"},{\"input_time\":\"1442563095\",\"mid\":\"9197516\",\"idx\":\"8\",\"account_id\":\"5628\",\"title\":\"\\u91cd\\u5e86\\u53c8\\u73b0\\u6700\\u7a84\\u4eba\\u884c\\u9053 \\u6700\\u7a84\\u5904\\u4ec520\\u5398\\u7c73\",\"id\":\"4561695\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18v_55fbc7c3a4ea6.jpg\",\"wurl\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=3528586285281575388&cid=1192652582&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=4701389649216307623&readId=a22e5104e5eef17609a41502941aba76&rd_type=reco\",\"url\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=3528586285281575388&cid=1192652582&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=4701389649216307623&readId=a22e5104e5eef17609a41502941aba76&rd_type=reco\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442563095\"},{\"input_time\":\"1442563014\",\"mid\":\"85127652\",\"idx\":\"7\",\"account_id\":\"5628\",\"title\":\"\\u8fd9\\u4e48\\u53ef\\u7231\\u7684\\u5973\\u5b69\\u5b50\\uff0c\\u6ca1\\u4eba\\u8981\\u771f\\u662f\\u6d6a\\u8d39\\u4e86\\u554a\\uff01\",\"id\":\"4561627\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18u_55fbc6e937915.jpg\",\"wurl\":\"http:\\/\\/toutiao.com\\/a6195756814317371650\\/?iid=2927750443&app=news_article\",\"url\":\"http:\\/\\/toutiao.com\\/a6195756814317371650\\/?iid=2927750443&app=news_article\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442563014\"},{\"input_time\":\"1442563006\",\"mid\":\"9197520\",\"idx\":\"2\",\"account_id\":\"5628\",\"title\":\"\\u5206\\u5e8a\\u7761OR\\u540c\\u5e8a\\u7761\\uff1f\\u5b9d\\u5b9d\\u7684\\u611f\\u53d7\\u6700\\u91cd\\u8981\\uff01\",\"id\":\"4561691\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18i_55fbc7b5cbb3b.jpg\",\"wurl\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=5370485498891609821&cid=408250330&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=809221406053202744&readId=16c1a0a57be51c0913a0feaf371432f6&rd_type=reco\",\"url\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=5370485498891609821&cid=408250330&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=809221406053202744&readId=16c1a0a57be51c0913a0feaf371432f6&rd_type=reco\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442563006\"},{\"input_time\":\"1442563006\",\"mid\":\"723586079\",\"idx\":\"3\",\"account_id\":\"5628\",\"title\":\"\\u4e00\\u987f\\u6b63\\u9910\\u7684\\u8d39\\u7528\\uff0c\\u73b0\\u5728\\u4f60\\u53ef\\u4ee5\\u4e70\\u5230\\u8fd9\\u6b3e\\u5e73\\u677f\",\"id\":\"4561655\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18k_55fbc72dc1523.jpg\",\"wurl\":\"http:\\/\\/www.zhikeji.net\\/news\\/22035.html\",\"url\":\"http:\\/\\/www.zhikeji.net\\/news\\/22035.html\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442563006\"},{\"input_time\":\"1442562985\",\"mid\":\"9124279\",\"idx\":\"3\",\"account_id\":\"5628\",\"title\":\"\\u5973\\u6444\\u5f71\\u5e08\\u548c\\u5979\\u7684\\u72d0\\u72f8\",\"id\":\"4561395\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18o_55fbc5e49cef9.jpg\",\"wurl\":\"http:\\/\\/inews.ifeng.com\\/yidian\\/44685810\\/news.shtml?ch=ref_zbs_ydzx_news\",\"url\":\"http:\\/\\/inews.ifeng.com\\/yidian\\/44685810\\/news.shtml?ch=ref_zbs_ydzx_news\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562985\"},{\"input_time\":\"1442562949\",\"mid\":\"1191793232\",\"idx\":\"8\",\"account_id\":\"5628\",\"title\":\"\\u4e5d\\u4e00\\u516b\\uff0c\\u5b89\\u4fdd\\u6cd5\\u6848\\u4e0e\\u5317\\u91ce\\u6b66\",\"id\":\"4561703\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18b_55fbc7cb97913.jpg\",\"wurl\":\"http:\\/\\/toutiao.com\\/a6195756573799235842\\/?iid=2927750443&app=news_article\",\"url\":\"http:\\/\\/toutiao.com\\/a6195756573799235842\\/?iid=2927750443&app=news_article\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562949\"},{\"input_time\":\"1442562921\",\"mid\":\"9124275\",\"idx\":\"6\",\"account_id\":\"5628\",\"title\":\"\\u4e704K\\u7535\\u89c6\\u662f\\u4e2a\\u5751\\uff1f\\u8fd9\\u4e9b\\u7406\\u7531\\u4f60\\u4e00\\u5b9a\\u4e0d\\u77e5\\u9053\",\"id\":\"4561421\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_184_55fbc60179217.jpg\",\"wurl\":\"http:\\/\\/news.zdwang.com\\/a\\/201509\\/1814112.html\",\"url\":\"http:\\/\\/news.zdwang.com\\/a\\/201509\\/1814112.html\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562921\"},{\"input_time\":\"1442562851\",\"mid\":\"9124274\",\"idx\":\"6\",\"account_id\":\"5628\",\"title\":\"\\u8c37\\u6b4c\\u773c\\u955c\\u66f4\\u540d\\u518d\\u6765 \\u53ef\\u7a7f\\u6234\\u8bbe\\u5907\\u884c\\u4e1a\\u524d\\u666f\\u63a2\\u8ba8\",\"id\":\"4561422\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_183_55fbc6026bb9c.jpg\",\"wurl\":\"http:\\/\\/external3.eastmoney.com\\/YDNews\\/ItemView.aspx?C=20150918549263227\",\"url\":\"http:\\/\\/external3.eastmoney.com\\/YDNews\\/ItemView.aspx?C=20150918549263227\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562851\"},{\"input_time\":\"1442562838\",\"mid\":\"85128212\",\"idx\":\"6\",\"account_id\":\"5628\",\"title\":\"J\\u8054\\u8d5b\\u591a\\u5927\\u7403 \\u4e2d\\u8d85\\u4e3b\\u80dc\\u6982\\u7387\\u9ad8\",\"id\":\"4561728\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18a_55fbc80975f6c.jpg\",\"wurl\":\"http:\\/\\/toutiao.com\\/a6195756174368014594\\/?iid=2927750443&app=news_article\",\"url\":\"http:\\/\\/toutiao.com\\/a6195756174368014594\\/?iid=2927750443&app=news_article\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562838\"},{\"input_time\":\"1442562835\",\"mid\":\"9124284\",\"idx\":\"9\",\"account_id\":\"5628\",\"title\":\"\\u7f8e\\u4e3d\\u53ea\\u97003\\u5206\\u949f\\uff1f\\u6700\\u6700\\u7b80\\u5355\\u7684\\u7f8e\\u4f53\\u7ec6\\u8282\",\"id\":\"4561363\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18a_55fbc5c3a76d0.jpg\",\"wurl\":\"http:\\/\\/www.yidianzixun.com\\/mp\\/content?id=963797\",\"url\":\"http:\\/\\/www.yidianzixun.com\\/mp\\/content?id=963797\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562835\"},{\"input_time\":\"1442562829\",\"mid\":\"595894194\",\"idx\":\"3\",\"account_id\":\"5628\",\"title\":\"\\u73a9\\u8f6c\\u751f\\u6001 ivvi\\u5c0fi Max\\u4e0evivo X5Pro\\u7cfb\\u7edf\\u5bf9\\u6bd4\",\"id\":\"4561650\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_187_55fbc71957009.jpg\",\"wurl\":\"http:\\/\\/toutiao.com\\/a6195756251677098241\\/?iid=2927750443&app=news_article\",\"url\":\"http:\\/\\/toutiao.com\\/a6195756251677098241\\/?iid=2927750443&app=news_article\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562829\"},{\"input_time\":\"1442562695\",\"mid\":\"42563817\",\"idx\":\"9\",\"account_id\":\"5628\",\"title\":\"\\u6700\\u65b0\\u70ed\\u70b9\\uff1a\\u641e\\u7b11\\u8bfa\\u8d1d\\u5c14\\u9881\\u5956\\uff0c\\u6700\\u65e0\\u5398\\u5934\\u7814\\u7a76\\u6765\\u4e86\",\"id\":\"4561621\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18w_55fbc6d99e687.jpg\",\"wurl\":\"http:\\/\\/page.iweek.ly\\/4pf3ug.html\",\"url\":\"http:\\/\\/page.iweek.ly\\/4pf3ug.html\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562695\"},{\"input_time\":\"1442562637\",\"mid\":\"9124262\",\"idx\":\"7\",\"account_id\":\"5628\",\"title\":\"\\u9c7c\\u5c3e\\u7eb9\\u600e\\u6837\\u5f71\\u54cd\\u7740\\u592b\\u59bb\\u611f\\u60c5?\",\"id\":\"4561519\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18p_55fbc64fbfbf8.jpg\",\"wurl\":\"http:\\/\\/m2.people.cn\\/r\\/MV80XzQ3MzkyNzBfOTUxXzE0NDI1NjI2Mzc=?__from=yidian\",\"url\":\"http:\\/\\/m2.people.cn\\/r\\/MV80XzQ3MzkyNzBfOTUxXzE0NDI1NjI2Mzc=?__from=yidian\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562637\"},{\"input_time\":\"1442562577\",\"mid\":\"9124270\",\"idx\":\"6\",\"account_id\":\"5628\",\"title\":\"\\u5f97\\u7f6a\\u4e86 Android \\u7c89\\u4e1d\\u7684\\u82f9\\u679c\\u642c\\u5bb6\\u5e94\\u7528\\uff0c\\u88ab\\u72e0\\u72e0\\u6253\\u5dee\\u8bc4\",\"id\":\"4561447\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18l_55fbc60bba3a3.jpg\",\"wurl\":\"http:\\/\\/app.qdaily.com\\/app\\/articles\\/15102.html\",\"url\":\"http:\\/\\/app.qdaily.com\\/app\\/articles\\/15102.html\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562577\"},{\"input_time\":\"1442562480\",\"mid\":\"681022160\",\"idx\":\"8\",\"account_id\":\"5628\",\"title\":\"SONY \\u7d22\\u5c3c HDR-AZ1 \\u4f69\\u6234\\u5f0f\\u8fd0\\u52a8\\u76f8\\u673a\",\"id\":\"4561653\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_189_55fbc7238c392.jpg\",\"wurl\":\"http:\\/\\/post.smzdm.com\\/p\\/341304\\/\",\"url\":\"http:\\/\\/post.smzdm.com\\/p\\/341304\\/\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562480\"},{\"input_time\":\"1442562454\",\"mid\":\"978962547\",\"idx\":\"10\",\"account_id\":\"5628\",\"title\":\"\\u7f8e\\u6d32\\u52a8\\u7269\\u8282\\u2014\\u2014\\u52a8\\u7269\\u5927\\u5de1\\u793c\",\"id\":\"4561424\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18l_55fbc600143a2.jpg\",\"wurl\":\"http:\\/\\/toutiao.com\\/a6195754860106957057\\/?iid=2927750443&app=news_article\",\"url\":\"http:\\/\\/toutiao.com\\/a6195754860106957057\\/?iid=2927750443&app=news_article\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562454\"},{\"input_time\":\"1442562420\",\"mid\":\"9197526\",\"idx\":\"4\",\"account_id\":\"5628\",\"title\":\"\\u4f60\\u9020\\u6709\\u79cd\\u98ce\\u8863\\u662f\\u9a6c\\u7532\\u5f0f\\u7684\\u5417\\uff1f\\u8d1d\\u5ac2\\u8d85\\u7231\\u7a7f\",\"id\":\"4561684\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18h_55fbc7af51f85.jpg\",\"wurl\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=9497108727108823831&cid=1213442674&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=7100447690087383815&readId=e14b3b2cc9233b6095c39b26a4969f9d&rd_type=reco\",\"url\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=9497108727108823831&cid=1213442674&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=7100447690087383815&readId=e14b3b2cc9233b6095c39b26a4969f9d&rd_type=reco\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562420\"},{\"input_time\":\"1442562413\",\"mid\":\"9124264\",\"idx\":\"9\",\"account_id\":\"5628\",\"title\":\"\\u61a8\\u8c46\\u7206\\u7b11\\u6076\\u641e\\u540d\\u753b \\u88c5\\u9970\\u5ba2\\u5385\\u8fd8\\u6015\\u6ca1\\u7b11\\u70b9\",\"id\":\"4561487\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18e_55fbc630a0e62.jpg\",\"wurl\":\"http:\\/\\/www.yidianzixun.com\\/mp\\/content?id=963738\",\"url\":\"http:\\/\\/www.yidianzixun.com\\/mp\\/content?id=963738\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562413\"},{\"input_time\":\"1442562403\",\"mid\":\"9124253\",\"idx\":\"3\",\"account_id\":\"5628\",\"title\":\"\\u4e8c\\u624b\\u8f66\\u5c0f\\u767d\\u8bf7\\u6ce8\\u610f\\uff0c\\u4ee5\\u4e0b\\u4e03\\u7c7b\\u4e8c\\u624b\\u8f66\\u4e0d\\u80fd\\u8fc7\\u6237\\u52ff\\u4e70\",\"id\":\"4560895\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18v_55fbc35c47be1.jpg\",\"wurl\":\"http:\\/\\/www.qctt.cn\\/news\\/show\\/id\\/69236\",\"url\":\"http:\\/\\/www.qctt.cn\\/news\\/show\\/id\\/69236\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562403\"},{\"input_time\":\"1442562379\",\"mid\":\"9124285\",\"idx\":\"5\",\"account_id\":\"5628\",\"title\":\"\\u7528\\u773c\\u5f71\\u600e\\u4e48\\u753b\\u773c\\u7ebf \\u624b\\u6b8b\\u515a\\u7684\\u65b0\\u601d\\u8def\\u773c\\u7ebf\\u5316\\u6cd5\",\"id\":\"4561361\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_181_55fbc5bdc2c97.jpg\",\"wurl\":\"http:\\/\\/www.7y7.com\\/caizhuang\\/98\\/143798.html\",\"url\":\"http:\\/\\/www.7y7.com\\/caizhuang\\/98\\/143798.html\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562379\"},{\"input_time\":\"1442562360\",\"mid\":\"2213309332\",\"idx\":\"1\",\"account_id\":\"5628\",\"title\":\"iOS 9\\u53c8\\u7529\\u5b89\\u5353\\u51e0\\u6761\\u8857\\uff1f\\u8fd9\\u4e2aAPP\\u5ef6\\u957f\\u5b89\\u5353\\u5f85\\u673a\\u79d2\\u6740\\u82f9\\u679c\",\"id\":\"4561489\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18j_55fbc638d1b6c.jpg\",\"wurl\":\"http:\\/\\/www.citnews.com.cn\\/internet\\/201509\\/248329.html\",\"url\":\"http:\\/\\/www.citnews.com.cn\\/internet\\/201509\\/248329.html\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562360\"},{\"input_time\":\"1442562278\",\"mid\":\"1191763888\",\"idx\":\"2\",\"account_id\":\"5628\",\"title\":\"\\u5199\\u7ed9\\u5929\\u4e0b\\u6240\\u6709\\u7684\\u5168\\u804c\\u5988\\u5988\",\"id\":\"4561001\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18k_55fbc3b4306c8.jpg\",\"wurl\":\"http:\\/\\/toutiao.com\\/a6195754155733106945\\/?iid=2927750443&app=news_article\",\"url\":\"http:\\/\\/toutiao.com\\/a6195754155733106945\\/?iid=2927750443&app=news_article\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562278\"},{\"input_time\":\"1442562212\",\"mid\":\"42562909\",\"idx\":\"9\",\"account_id\":\"5628\",\"title\":\"\\u76d8\\u70b9\\u6bd4\\u201c\\u5c0f\\u9ec4\\u4eba\\u201d\\u66f4\\u840c\\u7684N\\u79cd\\u52a8\\u7269\",\"id\":\"4560888\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18s_55fbc3558dde8.jpg\",\"wurl\":\"http:\\/\\/toutiao.com\\/a6195754134258778370\\/?iid=2927750443&app=news_article\",\"url\":\"http:\\/\\/toutiao.com\\/a6195754134258778370\\/?iid=2927750443&app=news_article\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562212\"},{\"input_time\":\"1442562203\",\"mid\":\"9197316\",\"idx\":\"6\",\"account_id\":\"5628\",\"title\":\"\\u7b80\\u535511\\u6b65 \\u6253\\u9020\\u6d6a\\u6f2b\\u97e9\\u5267\\u5973\\u4e3b\\u5377\\u53d1\\u4f4e\\u9a6c\\u5c3e\",\"id\":\"4561108\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18p_55fbc4874ed47.jpg\",\"wurl\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=17795188606848799292&cid=1213442674&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=7583132186747827177&readId=0825fff6bbfb5688ca056b5b6da45002&rd_type=reco\",\"url\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=17795188606848799292&cid=1213442674&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=7583132186747827177&readId=0825fff6bbfb5688ca056b5b6da45002&rd_type=reco\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562203\"},{\"input_time\":\"1442562120\",\"mid\":\"9124240\",\"idx\":\"6\",\"account_id\":\"5628\",\"title\":\"\\u62dc\\u4ec1\\u5927\\u5c06\\u6b32\\u7f5a\\u70b9\\u7403\\u88ab\\u74dc\\u5e05\\u5236\\u6b62 \\u5929\\u738b:\\u4e0d\\u4ecb\\u610f\\u4ed6\\u7f5a\",\"id\":\"4560991\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18i_55fbc3ac8f956.jpg\",\"wurl\":\"http:\\/\\/sports.sina.com.cn\\/global\\/germany\\/2015-09-18\\/doc-ifxhytwr2168440.shtml\",\"url\":\"http:\\/\\/sports.sina.com.cn\\/global\\/germany\\/2015-09-18\\/doc-ifxhytwr2168440.shtml\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562120\"},{\"input_time\":\"1442562120\",\"mid\":\"9124272\",\"idx\":\"8\",\"account_id\":\"5628\",\"title\":\"\\u5c0f\\u7c73\\u5e73\\u677f\\u4e8c\\u4ee3\\u6765\\u4e86\\uff01\\u652f\\u6301Windows 10\\u7cfb\\u7edf\",\"id\":\"4561426\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18n_55fbc6051efab.jpg\",\"wurl\":\"http:\\/\\/m.techweb.com.cn\\/yidian\\/2015-09-18\\/2204256.shtml\",\"url\":\"http:\\/\\/m.techweb.com.cn\\/yidian\\/2015-09-18\\/2204256.shtml\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562120\"},{\"input_time\":\"1442562060\",\"mid\":\"9197527\",\"idx\":\"9\",\"account_id\":\"5628\",\"title\":\"\\u5305\\u5305\\u642d\\u914d\\u662f\\u6280\\u672f\\u6d3b \\u79cb\\u5929\\u9002\\u5408\\u80cc\\u8fd9\\u4e9b\\u5305\",\"id\":\"4561682\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_186_55fbc7a140e63.jpg\",\"wurl\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=176047787788887969&cid=1213442674&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=14443707266590298919&readId=7c992af1fcaaa21dbb6093d411c29402&rd_type=reco\",\"url\":\"http:\\/\\/m.uczzd.cn\\/webapp\\/webview\\/article\\/news.html?aid=176047787788887969&cid=1213442674&zzd_from=uc-iflow&uc_param_str=dndseiwifrvesvntgi&recoid=14443707266590298919&readId=7c992af1fcaaa21dbb6093d411c29402&rd_type=reco\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562060\"},{\"input_time\":\"1442562004\",\"mid\":\"681003696\",\"idx\":\"1\",\"account_id\":\"5628\",\"title\":\"\\u6cb3\\u5357\\u9053\\u6559\\u540d\\u5c71--\\u8001\\u541b\\u5c71\",\"id\":\"4560781\",\"thumb\":\"http:\\/\\/file.weixinkd.com\\/article_201509_18_18r_55fbc2a657d46.jpg\",\"wurl\":\"http:\\/\\/www.ha.xinhuanet.com\\/hnxw\\/tttp\\/2015-09\\/18\\/c_1116606565.htm\",\"url\":\"http:\\/\\/www.ha.xinhuanet.com\\/hnxw\\/tttp\\/2015-09\\/18\\/c_1116606565.htm\",\"avatar\":\"http:\\/\\/file.weixinkd.com\\/account_201507_22_22g_55af5f547d8e45628.jpg\",\"account_name\":\"\\u5fae\\u770b\\u70b9\",\"ismuti\":\"0\",\"muti_list\":[],\"oid\":\"1442562004\"}]}";
        System.out.println(value.substring(9000,10000));

    }

    private static void createClassFromSql() {
        String value = "CREATE TABLE HOTSPOT_IMAGE_TABLE (_id INTEGER,id INTEGER PRIMARY KEY,pic TEXT,url TEXT,width INTEGER,height INTEGER,class_id INTEGER,url_type TEXT,name TEXT,link_id INTEGER,android_address TEXT)";
        PatternTest.matcher("\\(([\\w\\s,]+)\\)", "(_id INTEGER,id INTEGER PRIMARY KEY,pic TEXT,url TEXT,width INTEGER,height INTEGER,class_id INTEGER,url_type TEXT,name TEXT,link_id INTEGER,android_address TEXT)");
        Pattern compile = Pattern.compile("(CREATE|create)\\s+(TABLE|table)\\s+(\\w+)\\s+\\(([\\w\\s,]+)\\)");
//        id INTEGER PRIMARY KEY
//        avatar TEXT
//        name TEXT
//        description TEXT
//        isRead boolean default true

        HashMap<String, String> fieldTypes = new HashMap<>();
        fieldTypes.put("integer", "int");
        fieldTypes.put("string", "String");
        fieldTypes.put("float", "float");
        fieldTypes.put("long", "long");
        fieldTypes.put("double", "double");
        fieldTypes.put("boolean", "boolean");
        fieldTypes.put("text", "String");
        Pattern filedCompile = Pattern.compile("(\\w+)\\s+(INTEGER|integer|STRING|string|text|TEXT|BOOLEAN|boolean|FLOAT|float|LONG|long)" +
                "(\\s+(DEFAULT|default)\\s+(true|TRUE|FALSE|false))?");
        Matcher matcher = compile.matcher(value);
        ClassItem item = null;
        if (matcher.find()) {
            //class名称
            item = new ClassItem(matcher.group(3));
            //字段内容
            String filedValue = matcher.group(4);
            String[] filedArray = filedValue.split(",");
            for (int i = 0, length = filedArray.length; i < length; i++) {
//                id INTEGER PRIMARY KEY
//                avatar TEXT
//                isRead boolean Default true
                String fieldValue = filedArray[i].trim();
                Matcher fieldMatcher = filedCompile.matcher(fieldValue);
                if (fieldMatcher.find()) {
                    int count = fieldMatcher.groupCount();
                    String fieldName = fieldMatcher.group(1);
                    String type = fieldMatcher.group(2);
                    String defaultValue = fieldMatcher.group(5);
                    System.out.println("fieldName:" + fieldName + " type:" + type + " count:" + count + " default:" + defaultValue);
                    ClassItem.FieldItem fieldItem = new ClassItem.FieldItem();
                    fieldItem.name = fieldName;
                    fieldItem.type = fieldTypes.get(type.toLowerCase());
                    fieldItem.value = defaultValue;
                    item.fieldItems.add(fieldItem);
                }
            }
        }

        if (null != item) {
            StringBuffer builder = new StringBuffer();
            builder.append("package bean;\n");
            builder.append("/**\n");
            builder.append("* create by cz 2015/09/16;\n");
            builder.append("*/\n");
            builder.append("public class " + item.name + " {\n");
            item.fieldItems.forEach(fieldItem -> builder.append("\tpublic " + fieldItem.type + " " + fieldItem.name + (null == fieldItem.value ? "" : " = " + fieldItem.value) + ";\n"));
            builder.append("}\n");
            System.out.println(builder.toString());

            try {
                String property = System.getProperty("user.dir");
                BufferedWriter writer = new BufferedWriter(new FileWriter(new File(property + "/src/bean/" + item.name + ".java")));
                writer.write(builder.toString());
                writer.close();
            } catch (Exception e) {
            }
        }
    }

    /**
     * 解析xml
     *
     * @param file
     */
    private static void parserXml(File file) {
        //jdom解析xml
        Pattern p2 = Pattern.compile("(@(string|drawable|color|array)/(\\w*))|(\\?(attr)/(\\w*))");
        try {
            SAXBuilder builder = new SAXBuilder();
            Document document = builder.build(file);
            Element rootElement = document.getRootElement();
            LinkedList<Element> elements = new LinkedList<>();
            elements.add(rootElement);
            long l = System.currentTimeMillis();
            while (!elements.isEmpty()) {
                Element element = elements.removeFirst();
                List<Element> children = element.getChildren();
                if (null != children && !children.isEmpty()) {
                    elements.addAll(children);
                } else {
                    System.out.println("Element:" + element.getName());
                    List<Attribute> attributes = element.getAttributes();
                    int length = attributes.size();
                    for (int i = 0; i < length; i++) {
                        Attribute attribute = attributes.get(i);
                        Matcher m = p2.matcher(attribute.getValue());
                        while (m.find()) {
                            System.out.print(m.group(2) + " " + m.group(3) + " \n");
                        }
                    }
                    System.out.println();
                }
            }
            System.out.println("time:" + (System.currentTimeMillis() - l));
        } catch (JDOMException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
